#include <bits/stdc++.h>
using namespace std;

const int N = 1e7 + 5, Mod = 1e9 + 7;
int fac[N] = {1}, finv[N] = {1}, vis[N];
int qpow(int x, int k) {
    int res = 1;
    while(k) {
        if(k & 1)
            res = 1ll * res * x % Mod;
        x = 1ll * x * x % Mod;
        k >>= 1;
    }
    return res;
}
int C(int n, int m) {return 1ll * fac[n] * finv[m] % Mod * finv[n - m] % Mod;}

int main() {
    int l, r;
    cin >> l >> r;
    for(int i = 1; i <= r - l + 1; i++)
        fac[i] = 1ll * fac[i - 1] * i % Mod;
    finv[r - l + 1] = qpow(fac[r - l + 1], Mod - 2);
    for(int i = r - l + 1; i >= 1; i--)
        finv[i - 1] = 1ll * finv[i] * i % Mod;
    int cnt = 0;
    for(int i = l; i <= r; i++) {
        if(vis[i])
            continue ;
        ++cnt;
        for(int j = i + i; j <= r; j += i)
            vis[j] = 1;
    }
    long long ans = 0;
    int val = 1ll * fac[cnt] * fac[r - l + 1 - cnt] % Mod;
    for(int i = cnt; i <= r - l + 1; i++)
        ans += 1ll * C(i - 1, cnt - 1) * val % Mod * i % Mod;
    cout << ans % Mod << endl;
}