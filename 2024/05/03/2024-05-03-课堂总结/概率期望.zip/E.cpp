#include<bits/stdc++.h>
using namespace std;

int n, r;
double p[505], a[505], pw[505][505], f[505][505];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int T;
    cin >> T;
    while(T--) {
        cin >> n >> r;
        for(int i = 1; i <= n; i++) {
            cin >> p[i] >> a[i];
            pw[i][0] = 1;
            for(int j = 1; j <= r; j++)
                pw[i][j] = pw[i][j - 1] * (1 - p[i]);
        }
        memset(f, 0, sizeof(f));
        f[0][0] = 1;
        double ans = 0;
        for(int i = 1; i <= n; i++) {
            for(int j = 0; j <= min(i, r); j++) {
                f[i][j] = f[i - 1][j] * pw[i][r - j];
                if(j)
                    f[i][j] += f[i - 1][j - 1] * (1 - pw[i][r - j + 1]);
            }
            for(int j = 0; j <= min(i - 1, r); j++)
                ans += f[i - 1][j] * (1 - pw[i][r - j]) * a[i];
        }
        cout << fixed << setprecision(10) << ans << endl;
    }
}