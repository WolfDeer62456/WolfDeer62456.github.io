#include <bits/stdc++.h>
using namespace std;

const int N = 5e5 + 5;
int first[N], nxt[N << 1], to[N << 1], tot;
double w[N << 1];
void Add(int x, int y, double z) {
    nxt[++tot] = first[x];
    first[x] = tot;
    to[tot] = y;
    w[tot] = z;
}
int n;
double ans, f[N], g[N], val[N];

void dfs(int u, int fa) {
    f[u] = g[u];
    double res = 1;
    for(int e = first[u]; e; e = nxt[e]) {
        int v = to[e];
        if(v == fa)
            continue ;
        dfs(v, u);
        res *= (1 - w[e] * f[v]);
    }
    val[u] = res;
    f[u] += (1 - g[u]) * (1 - res);
}

void dfs2(int u, int fa) {
    ans += f[u];
    for(int e = first[u]; e; e = nxt[e]) {
        int v = to[e];
        if(v == fa)
            continue ;
        if(fabs(w[e] * f[v] - 1) > 1e-9) {
            double resu = val[u] / (1 - w[e] * f[v]);
            double fu = g[u] + (1 - g[u]) * (1 - resu);
            val[v] *= (1 - w[e] * fu);
            f[v] = g[v] + (1 - g[v]) * (1 - val[v]);
        }
        dfs2(v, u);
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin >> n;
    for(int i = 1; i < n; i++) {
        int a, b, p;
        cin >> a >> b >> p;
        Add(a, b, p / 100.0), Add(b, a, p / 100.0);
    }
    for(int i = 1; i <= n; i++) {
        cin >> g[i];
        g[i] /= 100;
    }
    dfs(1, 0);
    dfs2(1, 0);
    cout << fixed << setprecision(6) << ans << endl;
}