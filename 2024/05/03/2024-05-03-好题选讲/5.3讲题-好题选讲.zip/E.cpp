#include<bits/stdc++.h>
#define N 500010
#define LL long long
#define mod 1000000007
#define rep(i,l,r) for(int i=l;i<=r;i++)
using namespace std;
int rd() {
    int res=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9') {if(ch=='-') f*=-1;ch=getchar();}
    while(ch>='0'&&ch<='9') res=(res<<1)+(res<<3)+(ch^48),ch=getchar();
    return res*f;
}
int T,n,a[N],b[N],w[N],dep[N];
bool vis[N];
LL fac[N],ifac[N];
void dfs(int x) {
    vis[x]=1;
    if(a[x]<a[b[x]]) {
        dep[x]=1;
        return ;
    }
    if(a[x]>=a[b[x]]+w[b[x]]) {
        dep[x]=-1;
        return ;
    }
    if(dep[b[x]]==-1||b[x]==x) {
        dep[x]=-1;
        return ;
    }
    if(dep[b[x]]) {
        dep[x]=dep[b[x]]+1;
        return ;
    }
    if(vis[b[x]]){
        dep[x]=-1;
        return ;
    }
    dfs(b[x]);
    if(dep[b[x]]==-1) dep[x]=-1;
    else dep[x]=dep[b[x]]+1;
}
int main() {
    fac[0]=ifac[0]=fac[1]=ifac[1]=1;
    rep(i,2,N-10) fac[i]=fac[i-1]*i%mod,ifac[i]=mod-mod/i*ifac[mod%i]%mod;
    rep(i,2,N-10) ifac[i]=ifac[i-1]*ifac[i]%mod;
    T=rd();
    while(T--) {
        n=rd();
        rep(i,1,n) a[i]=rd();
        rep(i,1,n) b[i]=rd();
        rep(i,1,n) w[i]=rd(),dep[i]=vis[i]=0;
        rep(i,1,n) if(!dep[i]) dfs(i);
        rep(i,1,n) printf("%lld ",(a[i]+w[i]*ifac[dep[i]])%mod);
        puts("");
    }
    return 0;
}