#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int Read() {
    int x = 0, f = 1; char ch = getchar();
    while(!isdigit(ch) && ch != '-')  ch = getchar();
    if(ch == '-')  f = -1, ch = getchar();
    while(isdigit(ch))  x = x * 10 + ch - '0', ch = getchar();
    return x * f;  
}

const int N = 1e5 + 5;
int first[N], nxt[N << 1], to[N << 1], w[N << 1], tot;
void Add(int x, int y, int z) {
    nxt[++tot] = first[x];
    first[x] = tot;
    to[tot] = y;
    w[tot] = z;
}
int n, sum, ans, f[N][4], Fpos[N][4], g[N][2], gpos[N][2], h[N];
void upd_f(int u, int v, int dis) {
    if(dis > f[u][0]) {
        f[u][3] = f[u][2], Fpos[u][3] = Fpos[u][2];
        f[u][2] = f[u][1], Fpos[u][2] = Fpos[u][1];
        f[u][1] = f[u][0], Fpos[u][1] = Fpos[u][0];
        f[u][0] = dis, Fpos[u][0] = v;
    }
    else if(dis > f[u][1]) {
        f[u][3] = f[u][2], Fpos[u][3] = Fpos[u][2];
        f[u][2] = f[u][1], Fpos[u][2] = Fpos[u][1];
        f[u][1] = dis, Fpos[u][1] = v;
    }
    else if(dis > f[u][2]) {
        f[u][3] = f[u][2], Fpos[u][3] = Fpos[u][2];
        f[u][2] = dis, Fpos[u][2] = v;
    }
    else if(dis > f[u][3])
        f[u][3] = dis, Fpos[u][3] = v;
}
void upd_g(int u, int v, int val) {
    if(val > g[u][0]) {
        g[u][1] = g[u][0], gpos[u][1] = gpos[u][0];
        g[u][0] = val, gpos[u][0] = v;
    }
    else if(val > g[u][1])
        g[u][1] = val, gpos[u][1] = v;
}

void dfs1(int u, int fa) {
    for (int e = first[u]; e; e = nxt[e]) {
        int v = to[e];
        if(v == fa)
            continue;
        dfs1(v, u);
        upd_f(u, v, f[v][0] + w[e]);
        upd_g(u, v, h[v]);
    }
    h[u] = max(g[u][0], f[u][0] + f[u][1]);
}

void dfs2(int u, int fa) {
    ans = max(ans, f[u][0] + f[u][1] + f[u][2] + f[u][3]);
    for (int e = first[u]; e; e = nxt[e]) {
        int v = to[e];
        if(v == fa)
            continue;
        int tmp = h[v], disf = 0;
        if(Fpos[u][0] != v && Fpos[u][1] != v)
            disf = f[u][0] + f[u][1];
        else if(Fpos[u][0] == v)
            disf = f[u][1] + f[u][2];
        else
            disf = f[u][0] + f[u][2];
        if(gpos[u][0] == v)
            tmp += max(g[u][1], disf);
        else
            tmp += max(g[u][0], disf);
        ans = max(ans, tmp);
        upd_g(v, u, tmp - h[v]);
        disf = (Fpos[u][0] == v) ? f[u][1] : f[u][0];
        upd_f(v, u, w[e] + disf);
        h[v] = max(g[v][0], f[v][0] + f[v][1]);
        dfs2(v, u);
    }
}
signed main() {
    n = Read();
    for (int i = 1; i < n; i++) {
        int x = Read(), y = Read(), z = Read();
        sum += 2 * z;
        Add(x, y, z), Add(y, x, z);
    }
    dfs1(1, 0);
    dfs2(1, 0);
    cout << sum - ans << endl;
    return 0;
}