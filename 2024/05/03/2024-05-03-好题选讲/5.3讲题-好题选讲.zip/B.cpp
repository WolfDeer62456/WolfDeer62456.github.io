#include<bits/stdc++.h>
using namespace std;
#define rep(i,a,b) for(int i=(a);i<=(b);++i)
#define per(i,a,b) for(int i=(a);i>=(b);--i)
typedef long long ll;
typedef double db;
typedef pair<int,int> P;
#define fi first
#define se second
#define pb push_back
#define dbg(x) cerr<<(#x)<<":"<<x<<" ";
#define dbg2(x) cerr<<(#x)<<":"<<x<<endl;
#define SZ(a) (int)(a.size())
#define sci(a) scanf("%d",&(a))
#define pt(a) printf("%d",a);
#define pte(a) printf("%d\n",a)
#define ptlle(a) printf("%lld\n",a)
#define debug(...) fprintf(stderr, __VA_ARGS__)
const int N=2e5+10,M=18;
int n,a[N],u,v,r,t0,ans[N],dep[N],f[N][M],mx;
vector<int>e[N],d[N*2];
int lca(int x,int y){
	if(dep[x]<dep[y])swap(x,y);
	int d=dep[x]-dep[y];
	for(int i=17;i>=0;--i)
	if(d>>i&1)x=f[x][i];
	if(x==y)return x;
	for(int i=17;i>=0;--i){
		if(f[x][i]!=f[y][i])
		x=f[x][i],y=f[y][i];
	}
	return f[x][0];
}
int dis(int x,int y){
    int g=lca(x,y);
    return dep[x]+dep[y]-2*dep[g];
}
void dfs(int u,int fa){
    for(auto &v:e[u]){
        if(v==fa)continue;
        dep[v]=dep[u]+1;
        mx=max(mx,dep[v]);
        f[v][0]=u;
        rep(i,1,17){
            f[v][i]=f[f[v][i-1]][i-1];
        }
        d[dep[v]].pb(v);
        dfs(v,u);
    }
}
int main(){
    sci(n);
    rep(i,2,n){
        sci(u),sci(v);
        e[u].pb(v);
        e[v].pb(u);
    }
    sci(r),sci(t0);
    dfs(r,0);
    int p=r,q=r,now=0,cur=n;
    rep(i,0,2*n){
        for(auto &u:d[i]){
            int wp=dis(p,u),wq=dis(q,u),ori=dis(p,q);
            int big=max({wp,wq,ori});
            if(wp==big)q=u;
            else if(wq==big)p=u;
            now=big;
        }
        int far=(now+1)/2;
        if(i>=t0){
            while(cur>=1 && 1ll*cur*(i-t0)>=far){
                ans[cur]=i;
                cur--;
            }
        }
    }
    rep(i,1,n){
        printf("%d%c",ans[i]," \n"[i==n]);
    }
    return 0;
}