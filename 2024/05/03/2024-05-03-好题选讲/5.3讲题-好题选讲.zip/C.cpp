#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
typedef pair<int, int> PII;
typedef unsigned long long ULL;
const int N = 2e5 + 10, M = 1e6 + 10, mod = 1e9 + 7, MOD = 998244353;

void solve()
{
    int n; cin >> n;
    vector<LL> a(n + 1);
    vector<vector<LL>> dp(n + 1, vector<LL> (n + n + 1));

    for (int i = 1; i <= n; i ++)
    {
        int x; cin >> x;
        a[i] = a[i - 1] + x;
    }

    for (int i = 1; i <= n; i ++)
        for (int len = 0; len <= n + n; len ++)
        {
            int l = i - len, r = i + len;
            l = max(1, l);
            r = min(n, r);
            dp[i][len] = max(a[i] - a[l - 1], a[r] - a[i - 1]);
        }

    vector<vector<LL>> pre(n + 2, vector<LL> (n + n + 1));

    for (int i = n; i; i --)
        for (int j = 1; j <= n + n; j ++)
            pre[i][j] = max(dp[i][j], pre[i + 1][j - 1]);

    for (int i = 1; i <= n; i ++)
        for (int j = 1; j <= n + n; j ++)
            dp[i][j] = max(dp[i][j], dp[i - 1][j - 1]);

    for (int i = 1; i <= n; i ++)
        for (int j = 1; j <= n + n; j ++)
        {
            LL u = pre[i][j];
            dp[i][j] = max(u, dp[i][j]);
        }

    LL ans = 0;
    for (int i = 1; i <= n; i ++)
    {
        LL res = 0;
        for (int j = 1; j <= n + n; j ++)
            res ^= j * dp[i][j];
        ans ^= i + res;
    }

    cout << ans;
        
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T = 1; //cin >> T;
    while(T -- ) solve();

    return 0;
}