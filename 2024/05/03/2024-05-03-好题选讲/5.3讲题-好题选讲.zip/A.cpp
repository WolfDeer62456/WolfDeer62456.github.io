#include <bits/stdc++.h>
using namespace std;

map<long long, int> vis;
multiset<long long> s;
vector<long long> vec, ans;

bool check(long long u) {
    if(s.find(u) != s.end())
        return true;
    long long u1 = u / 2, u2 = u - u1;
    if(u1 & 1)
        swap(u1, u2);
    if(s.find(u1) != s.end()) {
        s.erase(s.find(u1));
        int flag = check(u2);
        s.insert(u1);
        return flag;
    }
    return false;
}
void doit(long long u) {
    if(s.find(u) != s.end()) {
        ++vis[u];
        s.erase(s.find(u));
        return;
    }
    doit(u / 2);
    doit(u - u / 2);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++) {
        long long x;
        cin >> x;
        s.insert(x);
        if(x % 2 == 0)
            vec.push_back(x);
    }
    sort(vec.begin(), vec.end());
    for(int i = vec.size() - 1; i >= 0; i--) {
        long long u = vec[i];
        if(vis[u]) {
            --vis[u];
            continue ;
        }
        s.erase(s.find(u));
        if(check(u + 1)) {
            doit(u + 1);
            s.insert(2 * u + 1);
        }
        else if(check(u - 1)) {
            doit(u - 1);
            s.insert(2 * u - 1);
        }
        else
            s.insert(u);
    }
    for(auto it = prev(s.end()); ; it--) {
        long long u = *it;
        ans.push_back(u);
        if(it == s.begin())
            break;
    }
    cout << ans.size() << '\n';
    for(auto u : ans)
        cout << u << ' ';
}