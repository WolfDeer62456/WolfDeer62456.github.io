#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <stdlib.h>
#include <math.h>
#include <vector>
#define ft first
#define sd second
#define pb push_back
using namespace std;

typedef pair<int,int> pii;

const int N=100000+5;
const int M=100000+5;
const int S=1<<19;

int n,m,cnt,op[M],v[N<<1],fa[N],L[N],R[N];
vector<int> seg[S];
pii q[M];

inline void rd(int& x)
{
	static char ch;
	static bool flag;
	for (flag=0;!isdigit(ch=getchar());flag=(ch=='-'));
	for (x=ch-48;isdigit(ch=getchar());x=x*10+ch-48);
	if (flag) x=-x;
}

inline void cmin(int& x,const int& y){if (y<x) x=y;}
inline void cmax(int& x,const int& y){if (y>x) x=y;}
inline int getfa(int x){return x==fa[x]?x:fa[x]=getfa(fa[x]);}

inline void modify(int x,int l,int r,int pos)
{
	vector<int>::iterator it;
	for (it=seg[x].begin();it!=seg[x].end();++it)
	{
		cmin(L[n],L[*it]);
		cmax(R[n],R[*it]);
		fa[getfa(*it)]=n;
	}
	seg[x].clear();
	if (l<r)
	{
		int mid=l+r>>1;
		if (pos<=mid) modify(x<<1,l,mid,pos);
		else modify((x<<1)+1,mid+1,r,pos);
	}
}

inline void addseg(int x,int l,int r,int le,int ri)
{
	if (le<=l && r<=ri){seg[x].pb(n);return;}
	int mid=l+r>>1,ch=x<<1;
	if (le<=mid) addseg(ch,l,mid,le,ri);
	if (ri>mid) addseg(ch+1,mid+1,r,le,ri);
}

inline void addseg(int l,int r)
{
	modify(1,1,cnt,l);
	modify(1,1,cnt,r);
	if (L[n]+1<R[n])
		addseg(1,1,cnt,L[n]+1,R[n]-1);
}

int main()
{
	freopen("interval.in","r",stdin);
	freopen("interval.out","w",stdout);
	rd(m);
	for (int i=1;i<=m;++i)
	{
		rd(op[i]);
		if (op[i]==1)
			rd(q[i].ft),rd(q[i].sd),
			v[++cnt]=q[i].ft,v[++cnt]=q[i].sd;
		else
			rd(q[i].ft),rd(q[i].sd);
	}
	sort(v+1,v+cnt+1);
	cnt=unique(v+1,v+cnt+1)-v-1;
	for (int i=1,fx,fy;i<=m;++i)
	{
		if (op[i]==1)
		{
			++n;fa[n]=n;
			q[i].ft=lower_bound(v+1,v+cnt+1,q[i].ft)-v;
			q[i].sd=lower_bound(v+1,v+cnt+1,q[i].sd)-v;
			L[n]=q[i].ft;R[n]=q[i].sd;
			addseg(q[i].ft,q[i].sd);
		}else{
			fx=getfa(q[i].ft);fy=getfa(q[i].sd);
			if (fx==fy) puts("YES");else
			if ((L[fy]<L[fx] && L[fx]<R[fy])||(L[fy]<R[fx] && R[fx]<R[fy]))
				puts("YES");
			else puts("NO");
		}
	}
	return 0;
}
