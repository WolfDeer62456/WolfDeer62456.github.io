# include <iostream>
# include <string.h>
# include <stdio.h>

using namespace std;
const int mod = 1e9 + 7;
const int M = 1e5 + 5;

char s[M];
int f[M], nxt[M][2];

int main() {
	freopen("alpha.in", "r", stdin);
	freopen("alpha.out", "w", stdout);
	int T; cin >> T;
	while(T --) {
		scanf("%s", s + 1);
		int n = strlen(s + 1);
		for (int i = 0; i <= n + 3; ++ i) nxt[i][0] = nxt[i][1] = f[i] = 0;
		bool ab_flag = true;
		for (int i = 2; i <= n; ++ i) if (s[i] == s[i - 1]) ab_flag = false;
		if(ab_flag) {
			puts("1");
			continue;
		}
		f[n + 1] = 1; nxt[n + 1][0] = nxt[n + 1][1] = nxt[n + 2][0] = nxt[n + 2][1] = n + 2;
		int sum = 0;
		for (int i = n; i >= 1; -- i) {
			sum = (sum + (s[i] == 'a' ? 1 : 2)) % 3;
			if (s[i] == 'a') {
				// a mod 3 = 1
				nxt[i][0] = i + 1;
			} else if (s[i + 1] == 'b') {
				// bb mod 3 = 1
				nxt[i][0] = i + 2;
			} else {
				// ba mod 3 = 0
				nxt[i][0] = nxt[i + 2][0];
			}
			if (s[i] == 'b') {
				// b mod 3 = 2;
				nxt[i][1] = i + 1;
			} else if (s[i + 1] == 'a') {
				// aa mod 3 = 2
				nxt[i][1] =  i + 2;
			} else {
				// ab mod 3 = 0
				nxt[i][1] = nxt[i + 2][1];
			}
			f[i] = f[nxt[i][0]] + f[nxt[i][1]];
			if (f[i] >= mod) f[i] -= mod;
			if (sum == 0) {
				f[i] ++;
				if (f[i] >= mod) f[i] -= mod;
			}
		}
		int ans = f[1];
		if (sum == 0) {
			ans --;
			if (ans < 0) ans += mod;
		}
		cout << ans << endl;
	}
	return 0;
}