# include <stdio.h>
# include <string.h>
# include <iostream>
# include <algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

const int M = 3e5 + 10;
const int mod = 1e9 + 7, inf = 1e7;

int n, m, rt[M];
struct edge {
  int u, v, w;
  edge() {}
  edge(int u, int v, int w) : u(u), v(v), w(w) {}
  friend bool operator < (const edge &a, const edge &b) {
    return a.w < b.w;
  }
}e[M];

int fat[M], mxv[M], tot = 0, ans[M];

int getf(int x) {
  return fat[x] == x ? x : fat[x] = getf(fat[x]); 
}

struct SMT {
  struct pa {
    int mx, id;
    pa() {}
    pa(int mx, int id) : mx(mx), id(id) {}
    friend pa operator + (const pa &a, const pa &b) {
      if(a.mx == b.mx) return a.id < b.id ? a : b;
      else return a.mx > b.mx ? a : b;
    }
  };
  
  void set() {ind = 0;}
  
  int ind;
  pa w[M * 20];
  int ls[M * 20], rs[M * 20];
  
  void ins(int &x, int l, int r, int c) {
    if(!x) x = ++ind;
    ls[x] = rs[x] = w[x].mx = w[x].id = 0;
    if(l == r) {
      w[x] = pa(1, c);
      return ;
    }
    int mid = l+r >> 1;
    if(c <= mid) ins(ls[x], l, mid, c);
    else ins(rs[x], mid+1, r, c);
    w[x] = w[ls[x]] + w[rs[x]];
  }
  
  int merge(int x, int y, int l, int r) {
    if(!x || !y) return x + y;
    if(l == r) {
      w[x].mx += w[y].mx;
      return x;
    }
    int mid = l+r >> 1;
    ls[x] = merge(ls[x], ls[y], l, mid);
    rs[x] = merge(rs[x], rs[y], mid+1, r);
    w[x] = w[ls[x]] + w[rs[x]];
    return x;
  }
} T;

int fa[M][18];

int main() {
  freopen("garden.in", "r", stdin);
  freopen("garden.out", "w", stdout); 
  
  std :: ios :: sync_with_stdio(false);
  std :: cin.tie(0);
  std :: cout.tie(0); 
  
  memset(rt, 0, sizeof rt);
  memset(fa, 0, sizeof fa);
  T.set();
  
  int type;
  cin >> n >> m >> type; tot = n;
  
  for (int i = 1, c; i <= n; ++ i) {
    cin >> c;
    T.ins(rt[i], 1, n, c);
    ans[i] = T.w[rt[i]].id;
  } 
  
  for (int i = 1, u, v, w; i <= m; ++ i) {
    cin >> u >> v >> w;
    e[i] = edge(u, v, w);
  }
  
  sort(e + 1, e + m + 1);
  
  for (int i = 1; i <= n; ++ i) fat[i] = i;
  
  for (int i = 1; i <= m; ++ i) {
    int fu = getf(e[i].u), fv = getf(e[i].v);
    if(fu == fv) continue;
    ++ tot; mxv[tot] = e[i].w;
    fat[tot] = tot;
    fat[fu] = fat[fv] = tot;
    fa[fu][0] = fa[fv][0] = tot;
    rt[tot] = T.merge(rt[fu], rt[fv], 1, n);
    ans[tot] = T.w[rt[tot]].id;
  }
  
  for (int j = 1; j <= 17; ++ j)
    for (int i = 1; i <= tot; ++ i)
      fa[i][j] = fa[fa[i][j-1]][j-1];
  
  mxv[0] = inf;
  
  int Q, a, b, lst = 0; 
  cin >> Q;
  while(Q --) {
    cin >> a >> b;
    if(type == 2) a ^= lst, b ^= lst;
    for (int i = 17; ~i; -- i)
      if(mxv[fa[a][i]] <= b) a = fa[a][i];
    lst = ans[a];
    cout << lst << '\n';
  }
  
  return 0;
}

