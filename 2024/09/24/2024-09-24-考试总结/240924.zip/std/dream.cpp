#include <bits/stdc++.h>
#define cs const
#define pb push_back
using namespace std;
cs int oo = 1e9 + 7; 
cs int N = 5e5 + 5; 
int n, q; 

int fix(int x) {
    if(x >= oo - 5) return oo; 
    return x; 
}

struct func {
    int v1, p, v2, vi; 
    func (int v1 = 0, int p = -1, int v2 = -1, int vi = oo) 
        : v1(v1), p(p), v2(v2), vi(vi) {}
    int operator () (cs int &x) {
        if(x == oo) return vi;
        if(x <= p) return v1; 
        return fix(v2 + x - p); 
    }
    void fit () {
        if(v1 < 0) {
            v1 = oo; 
        }
        if(v2 < -1) {
            p -= v2 + 1; 
            v2 = -1;
        }
        if(vi < 0) {
            vi = oo; 
        }
        v1 = fix(v1); 
        v2 = fix(v2); 
        vi = fix(vi);
        p = fix(p);
    }
    void trans() {
        if(v1 == oo) v1 = 0;
        if(vi == oo) vi = 0; 
    }
};

func operator + (cs func &a, cs func &b) {
    if(a.p == oo && b.p == oo) 
        return func(fix(a.v1 + b.v1), oo, 0, fix(a.vi + b.vi)); 
    if(a.p == oo) 
        return func(fix(a.v1 + b.v1), b.p, fix(a.v1 + b.v2), fix(a.vi + b.vi));
    if(b.p == oo)
        return func(fix(a.v1 + b.v1), a.p, fix(a.v2 + b.v1), fix(a.vi + b.vi));
    assert(0);
}



func F(func a, func b) {
    func c; 
    if(a.p == oo) {
        c = func (a.v1, oo, 0, a(b.vi));
        c.fit();
        return c; 
    }
    if(b.p == oo) {
        c = func (a(b.v1), oo, 0, a(b.vi)); 
        c.fit();
        return c;
    }
    c.vi = a(b.vi);
    c.p = b.p; 
    c.v1 = a(b.v1);
    if(a.p > b.v2) {
        c.p += a.p - b.v2; 
        c.v1 = a.v1; 
    }
    c.v2 = a(b(c.p + 1)) - 1;
    c.fit();
    return c; 
}

func flat (func x) {
    if(x.v1 == oo) x.v1 = 0; 
    if(x.vi == oo) x.vi = 0; 
    return x; 
}

struct skip {
    func a, c; 
    int d; 
    bool add;
    skip (func a = func(0, oo, 0, 0), func c = func(0, -1, -1, oo), int d = 0, bool add = 0) 
        : a(a), c(c), d(d), add(add) {}
    void operator += (cs skip &x) {
        if(x.add) {
            a = a + flat (F(x.a, c));
            add = 1; 
        }
        d += x.d; 
        c = F(x.c, c);
    }
};
#define mid ((l + r) >> 1) 
skip t[N << 2];

skip a[4] = {
    skip(func(0, oo, 0, 0), func(0, -1, 0, oo), 1, 0),
    skip(func(0, oo, 0, 0), func(oo, 0, -1, oo), -1, 0),
    skip(func(0, oo, 0, 0), func(0, -1, -1, 0), 0, 0),
    skip(func(0, -1, -1, 0), func(oo, oo, 0, oo), 0, 1)
};


void pbpb(skip & c, int op) {
    c += a[op - 1]; 
}

void put(int x, skip c) {
    t[x] += c; 
}

void down(int x) {
    put(x << 1, t[x]);
    put(x << 1 | 1, t[x]);
    t[x] = skip();
}

void modify (int x, int l, int r, int L, int R, int op) {
    if(L <= l && r <= R) {
        pbpb(t[x], op);
        return;
    }
    down(x);
    if(L <= mid) modify(x << 1, l, mid, L, R, op);
    if(R > mid) modify(x << 1 | 1, mid + 1, r, L, R, op); 
}

int query(int x, int l, int r, int p) {
    if(l == r) {
        return t[x].d - t[x].a(oo); 
    }
    down(x);
    if(p <= mid) return query(x << 1, l, mid, p);
    return query(x << 1 | 1, mid + 1, r, p);
}
#undef mid 

int main() {
	freopen("dream.in","r",stdin);
	freopen("dream.out","w",stdout);
	int n, q;
	scanf("%d%d", &n, &q);
	std::ios::sync_with_stdio(false), cin.tie(0);
    for(int z = 0; z < q; z++) {
        int op, l, r;
        scanf("%d%d%d", &op, &l, &r);
        if(op <= 4) {
            modify(1, 1, n, l, r, op);
        }
        if(op == 5) {
            cout << query(1, 1, n, l) + 500000 << '\n';
        }
    }       
    return 0; 
}
