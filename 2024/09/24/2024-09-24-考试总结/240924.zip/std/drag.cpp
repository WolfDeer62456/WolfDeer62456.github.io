#include <bits/stdc++.h>
#define cs const
#define pb push_back
using namespace std;
using pi = pair<int, int>;

void cmn(int &x, int y) {
    if (x > y) x = y;
}
cs int N = 1e6 + 5;

int n, a, b, f[N][2];

pi calc(int x, int y) {
    int ans = 0;
    if (x == y) {
        x += a;
        ++ans;
    }
    while (x != y) {
        if (x < y) x += a;
        else y += b;
        ++ans;
        if (x > n || y > n) return {0, 0};
    }
    return {x, ans};
}

int F(int x, int y, int n) {
    return (n - x) / a + (n - y) / b;
}

int main() {
    freopen("drag.in", "r", stdin);
    freopen("drag.out", "w", stdout);
    cin >> n >> a >> b;
    memset(f, 0x3f, sizeof f);


    pi p0 = calc(0, 0);
    int p0_x = p0.first, c0 = p0.second;

    if (p0_x == 0) {
        cout << F(0, 0, n) << '\n';
        return 0;
    }

    pi p1 = calc(-1, 0);
    pi p2 = calc(0, -1);
    f[p0_x][0] = f[p0_x][1] = c0;
    int ans = 1e9;

    for (int i = p0_x; i <= n; i++) {
        if (p1.first == 0) {
            cmn(ans, f[i][0] + F(i - 1, i, n));
        } else {
            if (i + p1.first > n) cmn(ans, f[i][0] + F(i - 1, i, n));
            else {
                cmn(f[i + p1.first][0], f[i][0] + p1.second);
                cmn(f[i + p1.first][1], f[i][0] + p1.second);
            }
        }
        if (p2.first == 0) {
            cmn(ans, f[i][1] + F(i, i - 1, n));
        } else {
            if (i + p2.first > n) cmn(ans, f[i][1] + F(i, i - 1, n));
            else {
                cmn(f[i + p2.first][0], f[i][1] + p2.second);
                cmn(f[i + p2.first][1], f[i][1] + p2.second);
            }
        }
    }
    cout << ans << '\n';
    return 0;
}
