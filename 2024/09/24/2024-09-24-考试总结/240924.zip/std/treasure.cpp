#include <bits/stdc++.h>
#define cs const
#define pb push_back
using namespace std;
using pi = pair<int, int>;

void cmn(int &x, int y) {
    if (x > y) x = y;
}

void cmx(int &x, int y) {
    if (x < y) x = y;
}

cs int oo = 1e9 + 7;

using ll = long long;
cs int mod = 998244353;

cs int N = 32, M = 1024;
int n, m, A, B;
vector<int> e[N];
int k;
int w[N];
int id[N];
vector<int> f[M];
vector<int> eb[N * N];

int index(int i, int j) {
    return i * n + j;
}

void work(vector<int> &f, vector<int> &b, vector<int> d) {
    f.resize(n * n);
    for (int i = 0; i < n * n; i++)
        f[i] = b[i];

    vector<bool> vis(n * n, false);
    priority_queue<pi> q;
    queue<int> det; // determine
    for (int i = 0; i < n * n; i++)
        if (f[i] != -oo) det.push(i), vis[i] = true;

    while (true) {
        if (q.empty() && det.empty()) break;
        if (!det.empty()) {
            int x = det.front();
            det.pop();
            for (int v : eb[x])
                if (!vis[v]) {
                    --d[v];
                    cmx(f[v], -f[x]);
                    q.push({f[v], v});
                    if (d[v] == 0) {
                        det.push(v);
                        vis[v] = true;
                    }
                }
        } else {
            pi top = q.top();  // ʹ�� pi ���͵ı��������� top ֵ
            q.pop();
            int v = top.first; // �⹹ pair
            int x = top.second;
            if (vis[x]) continue;
            if (f[x] > 0) {
                det.push(x);
                vis[x] = true;
            }
        }
    }
    
    for (int i = 0; i < n * n; i++)
        if (!vis[i]) f[i] = 0;
}

int main() {
    freopen("treasure.in", "r", stdin);
    freopen("treasure.out", "w", stdout);

    cin >> n >> m >> A >> B;
    --A, --B;
    for (int i = 0, u, v; i < m; i++) {
        scanf("%d%d", &u, &v);
        --u, --v;
        e[u].pb(v);
    }
    for (int i = 0; i < n; i++)
        id[i] = -1;
    
    cin >> k;
    for (int i = 0, x, y; i < k; i++) {
        scanf("%d%d", &x, &y);
        --x;
        id[x] = i;
        w[x] = y;
    }
    
    vector<int> d(n * n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int x = index(i, j);
            for (int v : e[i]) {
                int y = index(j, v);
                eb[y].pb(x);
                ++d[x];
            }
        }
    }
    
    f[0].resize(n * n);
    for (int S = 1; S < (1 << k); S++) {
        vector<int> b(n * n, -oo);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int x = index(i, j);
                if (id[i] >= 0 && (S >> id[i] & 1)) {
                    b[x] = w[i] + f[S ^ (1 << id[i])][x];
                }
            }
        }
        work(f[S], b, d);
    }
    
    cout << f[(1 << k) - 1][index(A, B)] << '\n';
    return 0;
}
