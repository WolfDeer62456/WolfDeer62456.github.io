#include <bits/stdc++.h>
#define cs const
#define pb push_back
using namespace std;
using pi = pair <int, int> ; 

void cmn(int &x, int y) {
    if(x > y) x = y; 
}
cs int N = 1e6 + 5; 

int n, a, b, f[N][2];

pi calc(int x, int y) {
    int ans = 0; 
    if(x == y) {
        x += a; 
        ++ ans; 
    }
    while(x != y) {
        if(x < y) x += a; 
        else y += b; 
        ++ ans; 
        if(x > n || y > n) return {0, 0};
    }
    return {x, ans};
}
int F(int x, int y, int n) {
    return (n - x) / a + (n - y) / b;
}

int main() {
	freopen("drag.in","r",stdin);
	freopen("drag.out","w",stdout);
    cin >> n >> a >> b; 
    memset(f, 0x3f, sizeof f);
    auto [p0, c0] = calc(0, 0);
    if(p0 == 0) {
        cout << F(0, 0, n) << '\n';
        return 0;
    }
    auto [p1, c1] = calc(-1, 0);
    auto [p2, c2] = calc(0, -1);
    f[p0][0] = f[p0][1] = c0; 
    int ans = 1e9; 
    for(int i = p0; i <= n; i++) {
        if(p1 == 0) {
            cmn(ans, f[i][0] + F(i - 1, i, n));
        }
        else {
            if(i + p1 > n) cmn(ans, f[i][0] + F(i - 1, i, n));
            else {
                cmn(f[i + p1][0], f[i][0] + c1);
                cmn(f[i + p1][1], f[i][0] + c1);
            }
        }
        if(p2 == 0) {
            cmn(ans, f[i][1] + F(i, i - 1, n));
        }
        else {
            if(i + p2 > n) cmn(ans, f[i][1] + F(i, i - 1, n));
            else {
                cmn(f[i + p2][0], f[i][1] + c2);
                cmn(f[i + p2][1], f[i][1] + c2);
            }
        }
    }
    cout << ans << '\n';
    return 0; 
}
