#include <bits/stdc++.h>
#define cs const
#define pb push_back
using namespace std;
using ll = long long ; 
using pi = pair <int, int> ; 
cs int N = 1e6 + 5; 

void cmn(ll &x, ll y) {
    if(x > y) x = y;
}
void cmx(ll &x, ll y) {
    if(x < y) x = y; 
}

int T; 
int n, m, q;
ll d[N];
ll c[N];
bool red[N];
vector <pi> e[N];

int dfn[N], cnt;
int st[20][N]; 

int mn(int x, int y) {
    return dfn[x] < dfn[y] ? x : y;
}

int lca(int x, int y) {
    if(x == y) return x; 
    if(dfn[x] > dfn[y]) swap(x, y);
    int lg = __lg(dfn[y] - dfn[x]);
    return mn(st[lg][dfn[x]], st[lg][dfn[y] - (1 << lg)]);
}

void dfs(int u, int f, int p) {
    st[0][cnt] = f; 
    dfn[u] = ++ cnt; 
    if(red[u]) p = u; 
    c[u] = d[u] - d[p];
    for(auto [v, w] : e[u])
    if(v != f) {
        d[v] = d[u] + w; 
        dfs(v, u, p);
    }
}

int ttt; 
void work() {
    int k; 
    scanf("%d", &k);
    ttt += k; 
    vector <int> a(k);
    for(int &x : a) scanf("%d", &x);
    sort(a.begin(), a.end(), [&](int x, int y) {
        return c[x] > c[y];
    });
    ll ans = 1e18; 
    int pnt = a[0];
    ll mxd = 0; 
    for(int i = 0; i < k; i++) {
        int x = a[i];
        pnt = lca(x, pnt);
        cmx(mxd, d[x]);
        cmn(ans, max(i + 1 < k ? c[a[i + 1]] : 0, mxd - d[pnt])); 
    }
    cout << ans << '\n';
}

int main() {
	freopen("disaster.in","r",stdin);
	freopen("disaster.out","w",stdout);
    scanf("%d%d%d", &n, &m, &q);
    for(int i = 1; i <= m; i++) {
        int x; 
        scanf("%d", &x);
        red[x] = 1; 
    }
    for(int i = 1, u, v, w; i < n; i++) {
        scanf("%d%d%d", &u, &v, &w);
        e[u].pb({v, w});
        e[v].pb({u, w});
    }
    cerr << n << ' ' << m << ' ' << q << endl;
    dfs(1, 0, 1);
    for(int i = 1; i < 20; i++)
    for(int j = 1; j + (1 << i) - 1 < n; j++)
    st[i][j] = mn(st[i - 1][j], st[i - 1][j + (1 << (i - 1))]);
    
    for(int t = 0; t < q; t++) {
        work();
    }
    for(int i = 0; i <= n; i++) {
        dfn[i] = 0; 
        e[i].clear();
        d[i] = c[i] = 0; 
        red[i] = 0; 
    }
    cnt = 0; 
    cerr << ttt << endl;
    return 0; 
}
