#include <bits/stdc++.h>
typedef long long ll;
using std::max; using std::min;
#define INF 1e18
#define rd() read<ll>()
#define lowbit(x) -x & x
#define E(i, l, r) for (int i = l; i <= r; ++ i)
#define FILE(filename) { \
  freopen(#filename ".in", "r", stdin); \
  freopen(#filename ".out", "w", stdout); \
}
template <typename T> inline T read() {
  T x = 0; char c = getchar(); bool f = 0;
  while (c < '0' || c > '9') {if (c == '-') f = 1; c = getchar();}
  while (c >= '0' && c <= '9') x = (x << 3) + (x << 1) + (c ^ 48), c = getchar();
  return f ? -x : x;
}
template <typename T> void write(T x) {
  if (x < 0) {putchar('-'); x = -x;}
  if (x / 10) write(x / 10);
  putchar((x % 10) ^ 48);
}
namespace pigeon {
  const int N = 1e5 + 5;
  #define int long long
  int n;
  ll d[N], res[N][61], ba[61];
  std::map<int, int> mp;
  std::vector<int> E[N];
  std::pair<int, int> ed[N];
  int dep[N], an[N][20], lc[N];
  void dfs(int cur, int fa) {
    dep[cur] = dep[fa] + 1;
    an[cur][0] = fa;
    E(i, 1, 19) an[cur][i] = an[an[cur][i - 1]][i - 1];
    for (auto go : E[cur])
      if (go != fa) dfs(go, cur);
  }
  int lca(int x, int y) {
    if (dep[x] < dep[y]) std::swap(x, y);
    for (int i = 19; ~i; -- i)
      if (dep[an[x][i]] >= dep[y])
        x = an[x][i];
    if (x == y) return x;
    for (int i = 19; ~i; -- i)
      if (an[x][i] != an[y][i])
        x = an[x][i], y = an[y][i];
    return an[x][0];
  }
  void Main() {
    n = rd(); ba[0] = 1;
    E(i, 1, 60) ba[i] = 2ll * ba[i - 1];
    E(i, 1, n - 1) {
      int x, y;
      x = rd(); y = rd();
      ed[i] = std::make_pair(x, y);
      E[x].push_back(y); E[y].push_back(x);
    } dfs(1, 0);
    E(i, 1, n - 1) {
      d[i] = rd();
      lc[i] = lca(i, i + 1);
    }
    E(i, 1, 60)
      E(j, 2, n)
        res[j][i] = (d[j - 1] - res[j - 1][i] + 2ll * res[lc[j - 1]][i - 1] % ba[i] + ba[i]) % ba[i];
    E(i, 1, n - 1)
      if (res[i][60] + res[i + 1][60] - 2ll * res[lc[i]][60] != d[i]) {write(-1); return;}
    E(i, 2, n)
      if (res[i][60] <= res[an[i][0]][60]) {write(-1); return;}
    E(i, 2, n) mp[an[i][0] * (n + 1) + i] = mp[i * (n + 1) + an[i][0]] = res[i][60] - res[an[i][0]][60];
    E(i, 1, n - 1) write(mp[ed[i].first * (n + 1) + ed[i].second]), puts("");
  }
}
signed main() {
  int T = 1;
  while (T --) pigeon::Main();
  return 0;
}
