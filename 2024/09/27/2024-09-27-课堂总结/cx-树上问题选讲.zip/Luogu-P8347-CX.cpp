#include <bits/stdc++.h>
using namespace std;
int t,n
#define N 100010
int deg[N];

int main(){
	scanf("%d", &t);
	while(t--){
		scanf("%d", &n);
		int u, v;
		memset(deg, 0, sizeof(deg));
		for(int i = 1; i < n; ++i){
			scanf("%d%d", &u, &v);
			++deg[u], ++deg[v];
		}
		bool flg = 0;
		for(int i = 1; i <= n; ++i){
			if(!(deg[i] & 1)){
				flg = 1;
				break;
			}
		}
		puts((flg) ? "Hifuu" : "Luna");
	}
	return 0;
}
