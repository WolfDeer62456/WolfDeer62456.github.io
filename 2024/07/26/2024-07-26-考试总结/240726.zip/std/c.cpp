#include<bits/stdc++.h>
using namespace std;
#define f(i,a,b) for (i=(a);i<=(b);i++ )
#define df(i,a,b) for (i=(a);i>=(b);i--)
#define ls k<<1,l,(l+r)>>1
#define rs k<<1|1,((l+r)>>1)+1,r
#define pb push_back
#define mp make_pair
#define int long long
const int N=3e5,I=1e4+1;
int n,m,lc[N][40],a[N],fa[N],x,y,as,cnt,cs,i,j,k,t,q[N],t1,q1[N];
string s;
int Gf(int e){return e==fa[e]?e:fa[e]=Gf(fa[e]);}
signed main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%d",&cs);
	while(cs--)
	{
		scanf("%d%d",&n,&m);
		memset(lc,0,sizeof(lc));
		f(i,1,n)fa[i]=i;
		f(i,1,n)
		{
			cin>>s;
			a[i]=0;f(j,0,m-1)if(s[j]=='Y')a[i]+=1<<j;
			lc[a[i]][0]=i;
		}
		cnt=n-1;as=0;
		f(i,0,m/2)
		{
			f(j,0,(1<<m)-1)if(lc[j][i])f(k,0,m-1)if(lc[j^(1<<k)][i])
			{
				x=Gf(lc[j^(1<<k)][i]),y=Gf(lc[j][i]);
				if(x!=y)fa[x]=y,as+=i*2+1,--cnt;
			}
			if(!cnt)break;
			f(j,0,(1<<m)-1)if(lc[j][i])f(k,0,m-1)
			if(lc[j^(1<<k)][i+1])
			{
				x=Gf(lc[j^(1<<k)][i+1]),y=Gf(lc[j][i]);
				if(x!=y)fa[x]=y,as+=i*2+2,--cnt;
			}
			else lc[j^(1<<k)][i+1]=lc[j][i];
			if(!cnt)break;
		}
		printf("%lld\n",as);
	}
	return 0;
}
