#include<bits/stdc++.h>
#define f(i,x,y) for(int i=x;i<=y;i++)
#define df(i,x,y) for(int i=x;i>=y;i--)
#define int long long
#define pb push_back
using namespace std;
const int N=1.1e6;
int n,cs,a[N],o[N],x,y,s,t,mn,mx;
signed main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%lld",&cs);
	while(cs--)
	{
		scanf("%lld",&n);
		f(i,0,n)o[i]=0;
		f(i,1,n)scanf("%lld",&a[i]),a[i]=min(a[i],n*2),o[a[i]]=1;
		f(i,0,n)if(!o[i]){s=i;break;}
		if(s==n)puts("No");
		else if(!o[s+1])puts("Yes");
		else
		{
			mn=0;
			f(i,1,n)if(a[i]==s+1){if(!mn)mn=i;mx=i;}
			f(i,mn,mx)a[i]=s;
			f(i,0,n)o[i]=0;
			f(i,1,n)o[a[i]]=1;
			f(i,0,n)if(!o[i]){t=i;break;}
			if(t==s+1)puts("Yes");else puts("No");
		}
	}
	return 0;
}
