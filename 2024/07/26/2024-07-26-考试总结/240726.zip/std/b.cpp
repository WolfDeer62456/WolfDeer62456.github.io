#include<bits/stdc++.h>
#define f(i,x,y) for(int i=x;i<=y;i++)
#define df(i,x,y) for(int i=x;i>=y;i--)
#define pb push_back
using namespace std;
const int N=1e6+10;
long long n,as,m,cs,y;
__int128 a[N],x;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%lld",&cs);
	while(cs--)
	{
		scanf("%lld%lld",&n,&m);
		f(i,1,n)a[i]=0;
		f(i,1,n)f(j,1,m)scanf("%lld",&x),a[i]+=x*j;
		x=min(a[1],a[2]);
		f(i,1,n)if(a[i]!=x){y=a[i]-x,cout<<i<<' '<<y<<'\n';break;}
	}
	return 0; 
}
