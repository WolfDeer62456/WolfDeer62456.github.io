#include<bits/stdc++.h>
using namespace std;
#define f(i,a,b) for (int i=(a);i<=(b);i++ )
#define df(i,a,b) for (int i=(a);i>=(b);i--)
#define ls k<<1,l,(l+r)>>1
#define rs k<<1|1,((l+r)>>1)+1,r
#define pb push_back
#define mp make_pair
const int R=5e3+10,C=2e2+10,N=3e5,I=2e9;
int n,m,q,fg,x,y,h[R][C],sum[R][C],z[R][C],f[R/4][C][C],g[C][C],a[C][C],b[C][C],c[C][C],p[C][C];
void hb(int le)
{
	f(i,1,m)f(j,1,m)c[i][j]=I;
	f(i,1,m)f(j,1,m)if(a[i][j]+b[j][i]+z[le][j]<c[i][i])p[i][i]=j,c[i][i]=a[i][j]+b[j][i]+z[le][j];
	
	f(i,2,m)for(int l=1,r=i;r<=m;l++,r++)
		f(k,p[l][r-1],p[l+1][r])if(a[l][k]+b[k][r]+z[le][k]<c[l][r])p[l][r]=k,c[l][r]=a[l][k]+b[k][r]+z[le][k];
	f(i,2,m)for(int r=1,l=i;l<=m;r++,l++)
		f(k,p[l-1][r],p[l][r+1])if(a[l][k]+b[k][r]+z[le][k]<c[l][r])p[l][r]=k,c[l][r]=a[l][k]+b[k][r]+z[le][k];
}
void bd(int k,int l,int r)
{
	if(r-l<=16)
	{
		f(j,1,m)f(o,1,m)f[k][j][o]=abs(sum[l][j]-sum[l][o]);
		f(i,l+1,r)
		{
			f(j,1,m)f(o,1,m)g[j][o]=abs(sum[i][j]-sum[i][o]);
			f(len,1,m)f(len1,1,m)a[len][len1]=f[k][len][len1];
			f(len,1,m)f(len1,1,m)b[len][len1]=g[len][len1];
			hb(i-1);
			f(len,1,m)f(len1,1,m)f[k][len][len1]=c[len][len1];
		}
		return;
	}
	bd(ls);bd(rs);
	f(len,1,m)f(len1,1,m)a[len][len1]=f[k<<1][len][len1];
	f(len,1,m)f(len1,1,m)b[len][len1]=f[k<<1|1][len][len1];
	hb((l+r)>>1);
	f(len,1,m)f(len1,1,m)f[k][len][len1]=c[len][len1];
}
void cg(int k,int l,int r,int u)
{
	if(r-l<=16)
	{
		f(j,1,m)f(o,1,m)f[k][j][o]=abs(sum[l][j]-sum[l][o]);
		f(i,l+1,r)
		{
			f(j,1,m)f(o,1,m)g[j][o]=abs(sum[i][j]-sum[i][o]);
			f(len,1,m)f(len1,1,m)a[len][len1]=f[k][len][len1];
			f(len,1,m)f(len1,1,m)b[len][len1]=g[len][len1];
			hb(i-1);
			f(len,1,m)f(len1,1,m)f[k][len][len1]=c[len][len1];
		}
		return;
	}
	if(u<=(l+r)/2)cg(ls,u);else cg(rs,u);
	f(len,1,m)f(len1,1,m)a[len][len1]=f[k<<1][len][len1];
	f(len,1,m)f(len1,1,m)b[len][len1]=f[k<<1|1][len][len1];
	hb((l+r)>>1);
	f(len,1,m)f(len1,1,m)f[k][len][len1]=c[len][len1];
}
signed main()
{
	freopen("d.in","r",stdin);
	freopen("d.out","w",stdout);
	scanf("%d%d",&n,&m);
	f(i,1,n)f(j,1,m-1)scanf("%d",&h[i][j]);//i,j i,j+1
	f(i,1,n-1)f(j,1,m)scanf("%d",&z[i][j]);
	f(i,1,n)f(j,1,m)sum[i][j]=sum[i][j-1]+h[i][j-1];
	bd(1,1,n);
	scanf("%d",&q);
	f(i,1,q)
	{
		scanf("%d%d%d",&fg,&x,&y);++x,++y;
		if(fg==3){printf("%d\n",f[1][x][y]);continue;}
		if(fg==1)
		{
			scanf("%d",&h[x][y]);
			f(j,1,m)sum[x][j]=sum[x][j-1]+h[x][j-1];
		}
		if(fg==2)scanf("%d",&z[x][y]);
		cg(1,1,n,x);
	}
	return 0;
}
