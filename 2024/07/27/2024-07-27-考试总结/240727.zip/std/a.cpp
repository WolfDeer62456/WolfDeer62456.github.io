#include<bits/stdc++.h>
#define f(i,x,y) for(int i=x;i<=y;i++)
#define df(i,x,y) for(int i=x;i>=y;i--)
#define pb push_back
#define L c[e][0]
#define R c[e][1]
using namespace std;
const int N=3e5+2;
int n,m,op,val[N],i,fa[N],tg[N],st[N],tp,c[N][2],s[N],t[N],v[N],f[N],as,fa1[N],b1[N][2],bl,b0[N][2],bl0;
vector<int>b[N],hv[N];
bool B(int e){return e==c[fa[e]][1];}
bool jn(int e){return c[fa[e]][0]==e||c[fa[e]][1]==e;}
void PU(int e){s[e]=s[L]+s[R]+(L&&f[L]!=f[e])+(R&&f[R]!=f[e]);}//{if(s[L])s[e]=s[L],t[e]=t[L];if(s[R])s[e]=s[R],t[e]=t[R];if(f[c[e][0]]!=f[e])s[e]=;}
void xz(int e){if(e)tg[e]^=1,swap(c[e][0],c[e][1]);}
void PD(int e){if(tg[e])tg[e]=0,xz(c[e][0]),xz(c[e][1]);}
void lrx(int e)
{
	int y=fa[e],z=fa[y],k=B(e),u=c[e][k^1];
	if(jn(y))c[z][B(y)]=e;c[e][k^1]=y,c[y][k]=u;
	fa[e]=z,fa[y]=e;if(u)fa[u]=y;
	PU(y),PU(e);
}
void Sp(int e)
{
	int y=e,z;st[tp=1]=e;
	while(jn(y))st[++tp]=y=fa[y];z=tp;
	while(tp)PD(st[tp--]);
	while(tp<z)PU(st[++tp]);
	while(jn(e))
	{
		if(jn(fa[e]))lrx(B(fa[e])^B(e)?e:fa[e]);
		lrx(e);
	}
}
void Access(int e){for(int j=0;e;e=fa[j=e])Sp(e),c[e][1]=j,PU(e);}
void mrt(int e){Access(e),Sp(e),xz(e);}
int frt(int e){Access(e),Sp(e);while(c[e][0])PD(e),e=c[e][0];while(fa[e])PU(e),e=fa[e];PU(e);while(c[e][0])PD(e),e=c[e][0];return e;}
void split(int u,int v){mrt(u),Access(v),Sp(v);}
void lk(int u,int v){mrt(u);if(frt(v)!=u)fa[u]=v;}
void cut(int u,int v)
{split(u,v);if(frt(v)==u&&fa[u]==v&&!c[u][1])c[v][0]=fa[u]=0,PU(v);}
int Gf(int e){return e==f[e]?e:f[e]=Gf(f[e]);}
void D(int e)
{
	v[e]=1;
	for(int u:b[e])if(!v[u])fa1[u]=e,b0[++bl0][0]=u,b0[bl0][1]=e,D(u);else if(u!=fa1[e])if(Gf(u)!=Gf(e))f[Gf(u)]=Gf(e);else b1[++bl][0]=u,b1[bl][1]=e;
}
int main()
{
	freopen("a.in","r",stdin);freopen("a.out","w",stdout);
	int x,y;
	scanf("%d%d",&n,&m);
	f(i,1,n)f[i]=i;
	f(i,1,m)scanf("%d%d",&x,&y),b[x].pb(y),b[y].pb(x);
	f(i,1,n)if(!v[i])D(i),++as;
	f(i,1,n)hv[Gf(i)].pb(i);
	f(i,1,bl0)lk(b0[bl0][1],b0[bl0][0]);
	
	f(i,1,bl)
	{
		x=b1[i][0],y=b1[i][1];
		split(x,y);
		if(s[y])
		{
			
			while(s[c[y][0]]||s[c[y][1]])if(s[c[y][0]])y=c[y][0];else y=c[y][1];
			if(c[y][0]&&f[y]!=f[c[y][0]]){x=c[y][0];while(c[x][1])x=c[x][1];}
			else {x=c[y][1];while(c[x][0])x=c[x][0];}
			if(hv[f[x]].size()>hv[f[y]].size())swap(x,y);
			for(int u:hv[f[x]]){hv[f[y]].pb(u),f[u]=y;while(jn(u)){PU(u);u=fa[u];}PU(u);}
			cut(x,y);lk(b1[i][0],b1[i][1]);
		}
	}
	f(i,1,n)as+=(Gf(i)==i);
	cout<<as;
//	for(i=1;i<=n;i++)scanf("%d",&val[i]); 
//	for(i=1;i<=m;i++)
//	{
//		scanf("%d%d%d",&f,&x,&y);
//		if(f==0)split(x,y),printf("%d\n",s[y]);
//		if(f==1)lk(x,y);
//		if(f==2)cut(x,y);
//		if(f==3)Sp(x),val[x]=y,PU(x);
//	}
	return 0;
}
