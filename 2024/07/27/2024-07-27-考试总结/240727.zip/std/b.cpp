#include<bits/stdc++.h>
#define f(i,x,y) for(int i=x;i<=y;i++)
#define df(i,x,y) for(int i=x;i>=y;i--)
#define int long long
using namespace std;
const int N=1.1e6;
int n,cs,a[N],o[N],x,y,t,l,fg;
char s[N];
signed main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%s",s+1);n=strlen(s+1);
	f(i,0,25)o[i]=0;
	f(i,1,n)++o[s[i]-'a'];
	l=0;fg=0;
	f(i,0,25)
	{
		f(j,1,o[i]/2)++l,s[l]=s[n-l+1]=i+'a';
		if(o[i]&1)
		{
			f(j,i+1,25)if(o[j])++fg;
			if(fg==1)
			{
				f(j,i+1,25)
				{
					while(o[j]>=2)s[++l]=j+'a',s[n-l+1]=j+'a',o[j]-=2;
					if(o[j])s[++l]=j+'a';
				}
				s[++l]=i+'a';
				break;
			}
			s[n-l]=i+'a';
			f(j,i+1,25)while(o[j]--)s[++l]=j+'a';
			break;
		}
	}
	printf("%s\n",s+1);
	return 0;
}
