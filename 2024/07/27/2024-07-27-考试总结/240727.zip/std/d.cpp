#include<bits/stdc++.h>
const int Mx=99999;
using namespace std;
int l[50][100000],r[50][100000],si[40],w[100000],bs[40],mx[1050000],ans,L,R,cs;
vector<int>d[10];
vector<pair<int,int> >q[100000];
int main(){
	freopen("d.in","r",stdin);freopen("d.out","w",stdout);
	for(int i=0;i<=Mx;i++)
	{
		for(int j=0;j<=45;j++) l[j][i]=max(0,i-1),r[j][i]=min(Mx,i+1);
		int tmp=i;
		for(int j=0;j<5;j++)w[i]=w[i]<<4|(tmp%10+1),tmp/=10;
	}
	for(int S=0;S<(1<<5);S++)
	{
		si[S]=si[S>>1]+(S&1);
		for(int j=0;j<5;j++)bs[S]=bs[S]<<4|((S>>j)&1?15:0);
		d[si[S]].push_back(bs[S]);
	}
	for(int k=2;k<=45;k++)
	{
		memset(mx,0,sizeof(mx));
		for(int i=0;i<=Mx;i++) for(int j=1;j<=min(5,k-1);j++)
		{
			int L=max(0,l[k-j-1][i]-1),R=r[k-j-1][i];
			for(int p=0;p<d[5-j].size();p++)q[L].push_back(make_pair(w[i]&d[5-j][p],R));//把状态抹掉一些位置方便转移 
		}
		for(int i=0;i<=Mx;i++)
		{
			while(!q[i].empty())
			{
				pair<int,int>now=q[i].back();q[i].pop_back();
				mx[now.first]=max(mx[now.first],now.second);
			}
			for(int S=0;S<(1<<5);S++) r[k][i]=max(r[k][i],mx[w[i]&bs[S]]);//更新 
		}
		memset(mx,0X3f,sizeof(mx));
		for(int i=0;i<=Mx;i++) for(int j=1;j<=min(5,k-1);j++)
		{
			int L=l[k-j-1][i],R=min(Mx,r[k-j-1][i]+1);
			for(int p=0;p<d[5-j].size();p++)q[R].push_back(make_pair(w[i]&d[5-j][p],L));
		} 
		for(int i=Mx;i>=0;i--)
		{
			while(!q[i].empty())
			{
				pair<int,int>now=q[i].back();q[i].pop_back();
				mx[now.first]=min(mx[now.first],now.second);
			}
			for(int S=0;S<(1<<5);S++) l[k][i]=min(l[k][i],mx[w[i]&bs[S]]);
		}
	}
	scanf("%d",&cs);
	while(cs--)
	{
		scanf("%d%d",&L,&R);ans=60;
		for(int i=L;i<=R;i++)
		{
			int res=0,now=i,cnt=1;
			while(now) cnt+=!!(now%10),now/=10;
			while(L<l[res][i]||r[res][i]<R) res++;
			ans=min(ans,res+cnt);
		}
		printf("%d\n",ans);
	}
	return 0;
}
