#include<bits/stdc++.h>
#define f(i,x,y) for(int i=x;i<=y;i++)
#define df(i,x,y) for(int i=x;i>=y;i--)
using namespace std;
const int N=220;
int n,m,a[N][N],h[N][N],l[N][N],as,t,t1,ls,fg,lk[N*N],v[N*N];
char s[N];
vector<int>b[N*N];
bool D(int e)
{
	v[e]=1;
	for(int u:b[e])if(!lk[u]||!v[lk[u]]&&D(lk[u])){lk[u]=e;return 1;}
	return 0;
}
signed main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%d%d",&n,&m);
	f(i,1,n)
	{
		scanf("%s",s+1);
		f(j,1,m)
		{
			if(s[j]=='o')a[i][j]=5;
			if(s[j]=='x')a[i][j]=6,++as;
			if(s[j]=='.')a[i][j]=7;
			if(isdigit(s[j]))a[i][j]=s[j]-'0';
		}
	}
	f(i,1,n)
	{
		ls=0;fg=0;a[i][m+1]=4;
		f(j,1,m+1)if(a[i][j]<=4)
		{
			if(ls!=j-1&&!fg&&(j-ls-1+(a[i][ls]>2)+(a[i][j]<3)&1))
			{
				++t;fg=0;//cout<<i<<ls+1<<' ';
				f(k,ls+1,j-1)if(a[i][k]!=5)h[i][k]=t,fg=1;
				if(!fg){puts("-1");return 0;}
			}
			if(ls==j-1&&(a[i][ls]>2)!=(a[i][j]<3)){puts("-1");return 0;}
			fg=0;ls=j;
		}
		else if(a[i][j]==6)fg=1;
	}
	t1=t;//cout<<1;
	f(j,1,m)
	{
		ls=0;fg=0;a[0][j]=1;
		f(i,1,n+1)if(a[i][j]<=4)
		{
			if(ls!=i-1&&!fg&&(i-ls-1+(a[ls][j]&1^1)+(a[i][j]&1)&1))
			{
				++t;fg=0;//cout<<ls+1<<j<<i-ls-1<<'\n';
				f(k,ls+1,i-1)if(a[k][j]!=5){fg=1;if(h[k][j])b[h[k][j]].push_back(t);}
				if(!fg){puts("-1");return 0;}
			}
			if(ls==i-1&&(a[ls][j]&1^1)!=(a[i][j]&1)){puts("-1");return 0;}
			fg=0;ls=i;
		}
		else if(a[i][j]==6)fg=1;
	}
	f(i,1,t1){f(j,1,t1)v[j]=0;t-=D(i);}
	cout<<m*n-as-t;
	return 0;
}
