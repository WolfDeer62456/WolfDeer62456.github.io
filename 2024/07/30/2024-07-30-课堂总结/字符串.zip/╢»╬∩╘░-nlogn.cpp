#include<bits/stdc++.h>
#define re register 
using namespace std;
const int MAXN = 1001234 ;
int f[MAXN][21];    
int nex[MAXN],l;
char s[MAXN];
int num[MAXN];
int dep[MAXN];
void getnex(){
    nex[1]=0;
    for(re int i=2,j=0;i<=l;i++){
        while(j&&s[j+1]!=s[i]) j=nex[j];
        if(s[j+1]==s[i]) j++;
        nex[i]=j;
    }
}
int Get(int x){
    re int tmp = (x>>1);
    for(re int i=20;i>=0;i--) if(f[x][i]>tmp) x=f[x][i];
    return dep[x]-1;
}
const long long mod = 1e9 + 7 ;
int main(){
    int T;
    scanf("%d",&T);
    while(T--){
        scanf("%s",s+1);l=strlen(s+1);
        getnex();
 		dep[0]=0;
 		for(re int i=1;i<=l;i++){
 			dep[i]=dep[nex[i]]+1;
 			f[i][0]=nex[i];
 			for(re int j=1;j<=20;j++) f[i][j]=f[f[i][j-1]][j-1]; 
 			num[i]=Get(i); 
		 }
        long long ans = 1 ;
        for(re int i=1;i<=l;i++) ans=ans*(num[i]+1)%mod;
        printf("%lld\n",ans);
    }
    return 0;
}
