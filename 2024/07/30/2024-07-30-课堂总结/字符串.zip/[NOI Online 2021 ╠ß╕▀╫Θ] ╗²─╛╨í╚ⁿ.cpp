#include<bits/stdc++.h>
using namespace std;
const int MAXN = 3012 ;
char a[MAXN] , b[MAXN] ;
int nex[MAXN][26] ;int t[26] ;
int n ; 
#define ull unsigned int long long 
const int mod = 1e9 + 33 ;

#define pii pair<ull,int>
const pii D = make_pair(31,29) ; 
pii M[MAXN] ;
inline pii operator * (const pii &x,const pii &y){return make_pair(x.first*y.first,1ll*x.second*y.second%mod);}
inline pii operator + (const pii &x,const pii &y){return make_pair(x.first+y.first,(    x.second+y.second)%mod);}
inline pii operator - (const pii &x,const pii &y){return make_pair(x.first-y.first,(mod+x.second-y.second)%mod);}
const int MOD = (1<<23) - 1 ;
struct Hash{
	int he[MOD+5] , tot = 0 , nex[6001234] ;ull Y[6001234];
	inline void ins(const pii &x){
		int now = x.second&MOD , u = he[now]; 
		while(u){
			if(Y[u]==x.first) return;
			u=nex[u];
		}
		tot++;nex[tot]=he[now];he[now]=tot;Y[tot]=x.first;
	}
}; 
int main(){
	scanf("%d",&n);
	scanf("%s",a+1);scanf("%s",b+1);
	M[0]=make_pair(1,1);
	for(int i=1;i<=n;i++) M[i]=M[i-1]*D;
	for(int i=n;i>=0;i--){
		memcpy(nex[i],t,sizeof(t));
		if(i) t[a[i]-'a']=i;
	}
	int ans = 0;
	Hash s;
	for(int l=1;l<=n;l++){
		int u = 0 ; pii H = make_pair(0,0);
		for(int r=l;r<=n;r++){
			H = H*D+make_pair(b[r]-'a'+1,b[r]-'a'+1);//ע��Ҫ��һ 
			int now = b[r] - 'a' ;
			if(nex[u][now]) u = nex[u][now] , s.ins(H) ; 
			else break;
		}
	}
	printf("%d\n",s.tot);
	return 0;
} 
