#include<bits/stdc++.h>
using namespace std;
const int MAXN = 20001234 ;
int z[MAXN<<1];
char s[MAXN<<1];
void getz(){
	int n = strlen(s) , l = 0 ;
	for(int i=1;i<n;i++){
		if(l+z[l]>i) z[i]=min(z[i-l],l+z[l]-i);
		while(i+z[i]<n&&s[z[i]]==s[i+z[i]]/*���z[i]����һ��ȡ��z[i-l]��һ��������*/) z[i]++;
		if(i+z[i]>l+z[l]) l=i;
	}
} 
char a[MAXN],b[MAXN];
int main(){
	scanf("%s",a);
	scanf("%s",b);
	int n = strlen(b) ;int m = strlen(a) ;
	for(int i=0;i<n;i++) s[i]=b[i];
	for(int i=0;i<m;i++) s[i+n]=a[i]; 
	getz();
	long long ansz = 0 , ansp = 0 ;
	ansz^=1ll*(strlen(b)+1)*(0+1) ;
	
	for(int i=1;i<n;i++) ansz^=1ll*(min(z[i],n-i)+1)*(i+1);
	
	for(int i=0;i<m;i++) ansp^=1ll*(min(z[i+n],n)+1)*(i+1);
	cout<<ansz<<"\n"<<ansp;
	return 0;
}
