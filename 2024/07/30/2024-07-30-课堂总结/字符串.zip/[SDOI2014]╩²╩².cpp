#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1610 ;
const int SIZ = 1610 ;
int ch[SIZ][10] , tot = 1 ;
char ins[SIZ];
bool ban[SIZ]; 
int fail[SIZ];vector<int> e[SIZ];
void Ins(){
	int u = 1 ;
	int l = strlen(ins+1) ;
	for(int i=1;i<=l;i++){
		int x = ins[i]-'0' ;
		if(!ch[u][x]) ch[u][x]=++tot;
		u=ch[u][x];
	}
	ban[u]=true;
}
int que[SIZ];
void bfs(){
	fail[1]=0;
	for(int i=0;i<10;i++) ch[0][i]=1;
	int l , r ; que[l=r=1]=1;
	for(;l<=r;l++){
		int u = que[l] ;
		for(int i=0;i<10;i++){
			if(ch[u][i]) que[++r]=ch[u][i],fail[ch[u][i]]=ch[fail[u]][i];
			else ch[u][i]=ch[fail[u]][i];
		}
	}
	for(int i=1;i<=tot;i++) e[fail[i]].emplace_back(i);
}
void dfs(int u,bool f){
	ban[u]|=f;
	for(auto x:e[u]) dfs(x,f|ban[x]);
}
const int mod = 1e9+7 ;
int f[MAXN][SIZ] ;int B[MAXN];
inline void Add(int &a,int b){((a+=b)>=mod)&&(a-=mod);}
int F(int pos,int u,bool lim,bool lead){
	if(ban[u]) return 0;
	if(!pos) return 1 ;  
	if(!lim&&(~f[pos][u])&&!lead) return f[pos][u];
	int res = 0 ;
	int up = lim?B[pos]:9 ;
	for(int i=0;i<=up;i++){
        if(lead&&i==0) Add(res,F(pos-1,1,lim&&i==up,1));
        else Add(res,F(pos-1,ch[u][i],lim&&i==up,0));
        
     }
	if(!lim&&!lead) f[pos][u]=res;
	return res ;
}
char s[MAXN];
int m;
int main(){
	scanf("%s",s+1);
	scanf("%d",&m);
	while(m--){
		scanf("%s",ins+1);
		Ins();
	}
	bfs();dfs(0,0);
	memset(f,-1,sizeof(f));
	int l = strlen(s+1) ;
	for(int i=1;i<=l;i++) B[i]=s[l-i+1]-'0' ;
	printf("%d\n",(F(l,1,1,1)+mod-1)%mod);
	return 0;
}
