#include<bits/stdc++.h>
#define int long long 
using namespace std;
const int mod = 1e9 + 7 ;
inline void Add(int &a,const int &b){((a+=b)>=mod)&&(a-=mod);}
int n;
char s[101234];
struct Matrix{
	int g[26][26];
	Matrix(){
		memset(g,0,sizeof(g));
	}
	Matrix operator * (const Matrix &x)const{
		Matrix res ;
		for(int i=0;i<26;i++){
			for(int k=0;k<26;k++){
				if(g[i][k]){
					for(int j=0;j<26;j++){
						Add(res.g[i][j],g[i][k]*x.g[k][j]%mod);
					}
				}
			}
		}
		return res ;
	}
}I;
Matrix Base;
Matrix mol(Matrix x,int y){
	Matrix res = I , tmp = x ;
	while(y){
		if(y&1ll) res=res*tmp;
		y>>=1;tmp=tmp*tmp;
	}
	return res ;
}

signed main(){
	scanf("%lld",&n);
	for(int i=0;i<26;i++) I.g[i][i]=1;
	scanf("%s",s+1);
	int l = strlen(s+1);
	for(int i=0;i<26;i++){
		for(int j=0;j<26;j++){
			Base.g[i][j]=1;
		}
	}
	for(int i=1;i<l;i++){
		int a = s[i]-'a' , b = s[i+1]-'a';
		Base.g[b][a]=0;
	} 
	Matrix ans = mol(Base,n-1);
	int res = 0 ;
	for(int i=0;i<26;i++){
		for(int j=0;j<26;j++) Add(res,ans.g[i][j]);
	}
	printf("%lld\n",res);
	return 0;
}
