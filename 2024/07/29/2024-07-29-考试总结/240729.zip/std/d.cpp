#include<bits/stdc++.h>
using namespace std;
constexpr int N=50000,M=100000,inf=1e9;
constexpr int tN=4*N+3,tM=M+4*N+10;
inline void up(int &x,int y){if(y>x) x=y;}
inline void down(int &x,int y){if(y<x) x=y;}
struct Edge{
	int u,v;
}E[M+10];
int Etop;
struct EDGE{
	int to,next;
}e[M+10];
struct EDGEw{
	int to,next,w;
}e1[tM*2+tN*2+10];
int head[N+10],etop,head1[tN+10],etop1;
int headc[tN+10],vis[tN+10],dis[tN+10];
void adde(int u,int v){
	e[etop].to=v;
	e[etop].next=head[u];
	head[u]=etop++;
}
void adde1(int u,int v,int w){
	e1[etop1].to=v;
	e1[etop1].next=head1[u];
	e1[etop1].w=w;
	head1[u]=etop1++;
}
void add(int u,int v,int w){
	adde1(u,v,w);
	adde1(v,u,0);
}
int deg[tN+10];
void add(int u,int v,int l,int r){
	deg[v]+=l;
	deg[u]-=l;
	add(u,v,r-l);
}
int dfn[N+10],low[N+10],clk,col[N+10],ctop;
deque<int> q;
int in[N+10],out[N+10],in_[N+10],out_[N+10];
void dfs(int x){
	dfn[x]=low[x]=++clk;
	q.push_back(x);
	vis[x]=1;
	int i;
	for(i=head[x];~i;i=e[i].next){
		if(vis[e[i].to]==2) continue;
		if(vis[e[i].to]) down(low[x],dfn[e[i].to]);
		else dfs(e[i].to),down(low[x],low[e[i].to]);
	}
	if(dfn[x]==low[x]){
		++ctop;
		int tmp;
		while(!q.empty()){
			tmp=q.back();
			q.pop_back();
			col[tmp]=ctop;
			vis[tmp]=2;
			if(tmp==x) break;
		}
	}
}
int lin[N+10],rin[N+10],lout[N+10],rout[N+10],lin_[N+10],rin_[N+10],lout_[N+10],rout_[N+10];
bool bfs(int x,int s){
	memset(dis,63,sizeof(dis));
	dis[x]=0;
	q.push_back(x);
	int i;
	while(!q.empty()){
		x=q.front();
		q.pop_front();
		for(i=head1[x];~i;i=e1[i].next){
			if(!e1[i^1].w) continue;
			if(dis[e1[i].to]>dis[x]+1){
				dis[e1[i].to]=dis[x]+1;
				q.push_back(e1[i].to);
			}
		}
	}
	return dis[s]<inf;
}
int dfs(int s,int t,int w){
	if(s==t) return w;
	vis[s]=1;
	int b=w,tmp;
	for(int &i=head1[s];~i;i=e1[i].next){
		if(vis[e1[i].to]) continue;
		if(!e1[i].w) continue;
		if(dis[e1[i].to]!=dis[s]-1) continue;
		tmp=dfs(e1[i].to,t,min(w,e1[i].w));
		w-=tmp;
		e1[i].w-=tmp;
		e1[i^1].w+=tmp;
		if(!w) break;
	}
	vis[s]=0;
	return b-w;
}
int Dinic(int s,int t){
	memset(vis,0,sizeof(vis));
	memcpy(headc,head1,sizeof(head1));
	int rv=0;
	while(bfs(t,s)){
		rv+=dfs(s,t,inf);
		memcpy(head1,headc,sizeof(head1));
	}
	return rv;
}
int main(){
	freopen("d.in","r",stdin);
	freopen("d.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	int T;
	cin>>T;
	while(T--){
		memset(head,255,sizeof(head));
		etop=0;
		int n,m,Q;
		cin>>n>>m>>Q;
		int i;
		Etop=0;
		for(i=1;i<=m;++i){
			int u,v;
			cin>>u>>v;
			adde(u,v);
			E[++Etop]={u,v};
		}
		int c1,c2;
		cin>>c1>>c2;
		bool flag=0;
		if(c1>c2){
			swap(c1,c2);
			flag=1;
		}
		memset(vis,0,sizeof(vis));
		clk=ctop=0;
		for(i=1;i<=n;++i){
			if(!vis[i]) dfs(i);
		}
		memset(in,0,sizeof(in));
		memset(out,0,sizeof(out));
		memset(in_,0,sizeof(in_));
		memset(out_,0,sizeof(out_));
		for(i=1;i<=m;++i){
			int u=E[i].u,v=E[i].v;
			++in[v],++out[u];
			++in_[col[v]],++out_[col[u]];
		}
		for(i=1;i<=n;++i){
			lin[i]=lout[i]=0;
			rin[i]=in[i];
			rout[i]=out[i];
		}
		for(i=1;i<=ctop;++i){
			lin_[i]=lout_[i]=0;
			rin_[i]=in_[i];
			rout_[i]=out_[i];
		}
		for(i=1;i<=Q;++i){
			int tp,x,op,l,r;
			cin>>tp>>x>>op>>l>>r;
			if(tp<=2) x=col[x];
			if(flag) op^=3;
			int tmp;
			if(tp==1) tmp=out_[x];
			else if(tp==2) tmp=in_[x];
			else if(tp==3) tmp=out[x];
			else tmp=in[x];
			if(op==2) l=tmp-l,r=tmp-r,swap(l,r);
			if(tp==1) up(lout_[x],l),down(rout_[x],r);
			else if(tp==2) up(lin_[x],l),down(rin_[x],r);
			else if(tp==3) up(lout[x],l),down(rout[x],r);
			else up(lin[x],l),down(rin[x],r);
		}
		memset(head1,255,sizeof(head1));
		etop1=0;
		int tid=3+2*(ctop+n);
		memset(deg,0,sizeof(deg));
		for(i=1;i<=ctop;++i){
			if(lout_[i]>rout_[i]||lin_[i]>rin_[i]) break;
			add(2,2+i,lout_[i],rout_[i]);
			add(2+ctop+n*2+i,tid,lin_[i],rin_[i]);
		}
		if(i<=ctop){
			cout<<"-1\n";
			continue;
		}
		for(i=1;i<=n;++i){
			if(lout[i]>rout[i]||lin[i]>rin[i]) break;
			add(2+col[i],2+ctop+i,lout[i],rout[i]);
			add(2+ctop+n+i,2+ctop+n*2+col[i],lin[i],rin[i]);
		}
		if(i<=n){
			cout<<"-1\n";
			continue;
		}
		for(i=1;i<=m;++i){
			int u=E[i].u,v=E[i].v;
			add(2+ctop+u,2+ctop+n+v,0,1);
		}
		add(tid,2,inf);
		int key=etop1-2,sum=0;
		for(i=2;i<=tid;++i){
			if(deg[i]>0) add(0,i,deg[i]),sum+=deg[i];
			if(deg[i]<0) add(i,1,-deg[i]);
		}
		int ans=Dinic(0,1);
		if(ans!=sum){
			cout<<-1<<'\n';
			continue;
		}
		ans=inf-e1[key].w;
		e1[key].w=e1[key^1].w=0;
		ans+=Dinic(2,tid);
		long long anss=(long long)ans*c1+(long long)(m-ans)*c2;
		cout<<anss<<'\n';
	}
	return 0;
}
