#include<bits/stdc++.h>
#define pb push_back
#define LEFT(x) (Sum(1, (x)) + small(rt[u], 1, n, m-(x)))
#define RIGHT(x) (Sum(len-(x)+1, len) + big(rt[u], 1, n, m-(x)))

using namespace std;
typedef long long ll;
typedef pair<int, int> PII;

template<typename T> inline void read(T &x){
	x = 0; bool F = 0; char c = getchar();
	for (;!isdigit(c);c = getchar()) if (c == '-') F = 1;
	for (;isdigit(c);c = getchar()) x = x*10+(c^48);
	if (F) x = -x;
}

template<typename T1, typename ...T2> inline void read(T1 &x, T2 &...y){read(x), read(y...);}

template<typename T> inline void checkmax(T &x, const T &y){if (x<y) x = y;}

template<typename T> inline void checkmin(T &x, const T &y){if (x>y) x = y;}

const int N = 5e5+5, M = 1.7e7;
vector<int> to[N];
int dep[N], n, m, x[N], y[N], sz[N];
ll z[N], ans[N];

int ls[M], rs[M], tot[M], rt[N], node;
ll sum[M];

namespace Segment_tree{
	
	void insert(int &x, int l, int r, int pos){
		if (!x) x = ++node; tot[x]++, sum[x] += pos;
		if (l == r) return; int mid = l+r>>1;
		if (pos<=mid) insert(ls[x], l, mid, pos);
		else insert(rs[x], mid+1, r, pos);
	}
	
	int merge(int u, int v){
		if (!u || !v) return u|v;
		tot[u] += tot[v], sum[u] += sum[v];
		ls[u] = merge(ls[u], ls[v]), rs[u] = merge(rs[u], rs[v]);
		return u;
	}
	
	ll big(int x, int l, int r, int k){
		if (l == r) return 1ll*l*k;
		int mid = l+r>>1, rsize = tot[rs[x]];
		if (k<=rsize) return big(rs[x], mid+1, r, k);
		return sum[rs[x]] + big(ls[x], l, mid, k-rsize);
	}
	
	ll small(int x, int l, int r, int k){
		if (l == r) return 1ll*l*k;
		int mid = l+r>>1, lsize = tot[ls[x]];
		if (k<=lsize) return small(ls[x], l, mid, k);
		return sum[ls[x]]+small(rs[x], mid+1, r, k-lsize);
	}
	
} using namespace Segment_tree;

inline ll Sum(int x, int y){
	return 1ll*(x+y)*(y-x+1)/2;
}

void dfs(int u, int fa){
	dep[u] = dep[fa]+1;
	for (int v: to[u]){
		if (v!=fa) dfs(v, u), rt[u] = merge(rt[u], rt[v]), sz[u] += sz[v];
	}
	// cal
	int l = max(x[u], m - sz[u]), len = dep[u]-1, r = min(len, m-y[u]);
	ll Left, Right, v = z[u] + 1ll*m*dep[u]; // ?? 
	if (l<=r){
		Left = LEFT(r), Right = RIGHT(l);
		if (Right<=v) ans[u] = v-Right;
		else if (v<=Left) ans[u] = Left-v;
		else{
			if ((l == 0 || r == len) && l<r){
				if (l == 0){
					Left = LEFT(l), Right = RIGHT(l+1);
					if (Right<v && v<Left) ans[u] = 1;
					else ans[u] = 0;
				}
				if (r == len){
					Right = RIGHT(r), Left = LEFT(r-1);
					if (Right<v && v<Left) ans[u] = 1;
					else ans[u] = 0;
				}
			}
			else ans[u] = 0;
		}
	}
	else ans[u] = -1;
	insert(rt[u], 1, n, dep[u]), sz[u]++;
}

int main(){
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);
	read(n, m); int u, v; for (int i = 1;i<n;i++) read(u, v), to[u].pb(v), to[v].pb(u);
	for (int i = 1;i<=n;i++) read(x[i], y[i], z[i]);
	dfs(1, 0);
	for (int i = 1;i<=n;i++) printf("%lld ", ans[i]);
	return 0;
}
