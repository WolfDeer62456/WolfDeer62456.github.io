#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define IOS ios::sync_with_stdio(false),cin.tie(nullptr)
#define _for(i,a,b) for(int i=(a) ;i<=(b) ;i++)
#define _rep(i,a,b) for(int i=(a) ;i>=(b) ;i--)
#define mst(v,s) memset(v,s,sizeof(v))
#define pii pair<int ,int >
#define pb(v) push_back(v)
#define all(v) v.begin(),v.end()
#define inf 0x3f3f3f3f
#define INF 0x7f7f7f7f7f7f7f7f
#define endl "\n"
#define fi first
#define se second
#define ls p<<1
#define rs p<<1|1
#define lson p<<1,l,mid
#define rson p<<1|1,mid+1,r
#define AC return 0
#define ldb long double
#define de2(a,b) cout<<" de "<<endl;cout<<a<<" : "<<b<<endl;
#define de3(a,b,c) cout<<" de "<<endl;cout<<a<<" : "<<b<<" : "<<c<<endl;
const int N=1e5+5;
const int mod=1e9+7;
const double eps=1e-8;
int n,m;
int s[N],id[N];
char s1[N],s2[N];
bitset<N> ans,tmp,one;
void solve(){
    ans.reset();
    tmp.reset();
    cin>>n;
    cin>>(s1+1);cin>>(s2+1);
    one[0]=0;
    _for(i,1,n){
        s[i] = s[i-1] + (s1[i]=='1'?1:-1);
        one[i] = 1;
    }
    iota(id,id+n+1,0);
    sort(id,id+n+1,[&](const int &i,const int &j){
        return s[i]!=s[j]?s[i]>s[j]:i<j;
    });
    _for(i,0,n){
        int pos = id[i];
        if( pos ){
            if( s2[pos] == '1' ){
                ans |= tmp>>(n-pos);
            }
            else{
                ans |= (tmp^one)>>(n-pos);
            }
        }
        tmp[n-pos]=1;
    }
    _for(i,1,n){
        if( ans[i] ) cout<<0;
        else cout<<1;
    }
    cout<<endl;
}
signed main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
    IOS;
    int T=1;
    while(T--) solve();
    AC;
}
