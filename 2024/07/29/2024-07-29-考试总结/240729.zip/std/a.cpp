#include<bits/stdc++.h>
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)
#define eb emplace_back
#define mp make_pair
#define fi first
#define se second
using namespace std;
typedef long long ll;
constexpr int N=1e5+5;
int T,n,m;ll a[N],b[N];
inline void rd(int &x){
    x=0;char ch=getchar();int f=1;
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
    x*=f;
}
inline void rdl(ll &x){
    x=0;char ch=getchar();int f=1;
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
    x*=f;
}
inline int id(int x,int y){return(x-1)*m+y;}
inline void solve(){
	ll ans=0;
	vector<ll>vec;
	rd(n),rd(m);
	For(i,1,n*m)rdl(a[i]);
	For(i,1,n*m)rdl(b[i]);
	For(i,1,n*m)a[i]=b[i]-a[i];
	For(i,1,n)For(j,1,m)
		if(a[id(i,j)]-a[id(i,1)]!=a[id(1,j)]-a[id(1,1)]){
			return puts("-1"),void();
		}
	For(i,1,n)vec.eb(a[1]-a[(i-1)*m+1]);
	For(i,1,m)vec.eb(a[i]);
	sort(vec.begin(),vec.end());
	ll x=vec[(n+m)/2];
	for(auto p:vec)ans+=abs(x-p);
	printf("%lld\n",ans);
}
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	for(rd(T);T--;)solve();
	return 0;
}
