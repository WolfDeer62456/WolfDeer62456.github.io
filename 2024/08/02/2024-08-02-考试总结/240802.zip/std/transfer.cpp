#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<3)+(s<<1)+(ch^48);
		ch=getchar();
	}
	return w*s;
}
const int MAXN = 101234 ;
const int MAXM = 23 ;
int n,m,k;
const int M2 = 37 ;
int cost[MAXM+1][(1<<22)+50];
int dp[(1<<MAXM)+50];int d[123][123];
inline void Min(int &a,const int &b){(a>b)&&(a=b);}
int pos[40];
int a[MAXN];int siz[(1<<22)+50];
inline int lowbit(const int &x){return x&(-x);}
inline int To(const int &i,const int &S){
//	printf("To(%d,%d)=%d\n",i,S,(S&((1<<i)-1))|((S>>i)<<(i-1)));
	return (S&((1<<i)-1))|((S>>i)<<(i-1));
}
int A_D[(1<<22)+50],B_C[(1<<22)+50];
int main(){
	freopen("transfer.in","r",stdin);
	freopen("transfer.out","w",stdout); 
	n=read(),m=read(),k=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<n;i++) d[a[i]][a[i+1]]++;
	int up=(1<<m)-1;
	for(int i=1;i<=m;i++) pos[(1<<i)%M2]=i;
	
	for(int i=1;i<=(up>>1);i++){
		for(int j=i;j;j-=lowbit(j)) siz[i]++; 
	}
	
	for(int i=1;i<=m;i++){
		for(int S=0;S<=(up>>1);S++){
			if(!S){
				int A=0,B=0,C=0,D=0;
				for(int j=1;j<m;j++){
					int now=j+(j>=i);
					B+=d[now][i],D+=d[i][now];
				}
				A_D[S]=A-D;B_C[S]=B+C;
			}
			else{
				int p=pos[lowbit(S)%M2]+1;
				p=p+(p>=i);int pre=(S^lowbit(S));
				int AD=A_D[pre],BC=B_C[pre];
				AD+=d[p][i];AD+=d[i][p];
				BC+=d[i][p];BC-=d[p][i];
				A_D[S]=AD;B_C[S]=BC;
			}
		}
		for(int S=0;S<=(up>>1);S++){
			int v=siz[S]+1;
			cost[i][S]=A_D[S]*v+B_C[S]*v*k;
		//	printf("cost[%d][%d]=%d\n",i,S,cost[i][S]);
		}
	}
	memset(dp,0x3f3f3f3f,sizeof(dp));
	dp[0]=0;
	for(int i=0;i<up;i++){
	//	printf("dp[%d]=%d\n",i,dp[i]);
		for(int j=1;j<=m;j++){
			if((i>>(j-1))&1) continue ;
			Min(dp[i|(1<<(j-1))],dp[i]+cost[j][To(j,i)]);
		}
	//	printf("dp[%d]=%d\n",up,dp[up]);
	}
	printf("%d\n",dp[up]);
	return 0;
}
