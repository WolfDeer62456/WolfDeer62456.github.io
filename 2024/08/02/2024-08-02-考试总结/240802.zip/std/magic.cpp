#include<bits/stdc++.h>
#define int long long 
using namespace std;
const int MAXN = 15012 ;
int cou[MAXN] ;
int n , m  ;
int sum[MAXN] ; 
int A[MAXN] , B[MAXN] , C[MAXN], D[MAXN] ;
int val[40123]; 
inline int read(){
	int w = 1 , s= 0 ;
	char ch = getchar() ;
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s = s*10 + (ch-'0');
		ch=getchar();
	}
	return w*s;
}
signed main(){
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout); 
	n = read() , m=read() ;
	for(int i=1;i<=m;i++) val[i]=read(),cou[val[i]]++;
	for(int t=1;t*9<n;t++){
		memset(sum,0,sizeof(sum));
		for(int i=n-t;i>t*8;i--) sum[i]=sum[i+1]+cou[i]*cou[i+t];
		for(int a=0,b=a+2*t;a+t*9<n;a++,b++){
			int tmp = sum[a+t*8+1];
			A[a]+=tmp*cou[b],B[b]+=tmp*cou[a];
		}
		memset(sum,0,sizeof(sum));
		for(int i=t*2;i<n-t*7;i++) sum[i]=sum[i-1]+cou[i]*cou[i-t*2];
		for(int c=n-t,d=c+t;c>t*6;c--,d--){
			int tmp = sum[c-t*6-1];
			C[c]+=tmp*cou[d],D[d]+=tmp*cou[c];
		} 
	}
	for(int i=1;i<=m;i++) printf("%lld %lld %lld %lld\n",A[val[i]],B[val[i]],C[val[i]],D[val[i]]);
	return 0;
}
