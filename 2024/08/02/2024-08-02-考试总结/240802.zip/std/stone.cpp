#include<bits/stdc++.h> 
using namespace std;
const int e = 2e6 + 5 ;
char b[e] ;
int n , nxt[e] , ans[e] ;
inline void solve(int l,int r){
	nxt[1] = 0 ;
	int i , j = 0 ;
	for(i = l+1;i<=r;i++){
		while(j>0&&b[j+l]!=b[i]) j=nxt[j] ;
		if(b[j+l]==b[i]) j++;
		nxt[i-l+1] = j ; 
	}
	int len = r - l + 1;
	for(i=1;i<=len;i++) ans[i]++;
	while(j){
		ans[len-j+1]-- ;
		j = nxt[j] ; 
	}
} 
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout); 
	int t = 0 ;
	while(~scanf("%s",b+1)){
		t++ ;
		int i , pre = 1 ;
		n = strlen(b+1) ;
		for(i=1;i<=n;i++) b[i+n]=b[i] ;
		for(i=1;i<=n;i++) ans[i]=0;
		for(i=2;i<=n*2;i++) 
			if(b[i]==b[i-1]){
				solve(pre,i-1);
				pre = i ; 
			}
		solve(pre,2*n);
		printf("Case %d:",t);
		for(i=0;i<n;i++)
			if(ans[n-i])
				putchar('1');
			else
				putchar('0');
		putchar('\n');
	}
	return 0;
}
