#include<bits/stdc++.h>
#define re register 
using namespace std;
inline int read(){
	re int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return w*s;
}
const int MAXN = 600000 ;
const int MAXH = 20 ;
int w[MAXN*MAXH],ch[MAXN*MAXH][2],xorv[MAXN*MAXH];
int tot;
inline int node(){
	tot++;ch[tot][0]=ch[tot][1]=w[tot]=xorv[tot]=0;
	return tot;
}
void maintain(int u){
	w[u]=xorv[u]=0;
	if(ch[u][0]){
		w[u]+=w[ch[u][0]];
		xorv[u]^=(xorv[ch[u][0]]<<1);
	}
	if(ch[u][1]){
		w[u]+=w[ch[u][1]];
		xorv[u]^=((xorv[ch[u][1]]<<1)|(w[ch[u][1]]&1));
	}
	w[u]=w[u]&1;
}
void insert(int &u,int x,int dep){
	if(!u) u=node();
	if(dep>MAXH){
		w[u]++;return ;
	}
	insert(ch[u][x&1],x>>1,dep+1);
	maintain(u);
}
int merge(int a,int b){
	if(!a||!b) return a+b;
	w[a]=w[a]+w[b];
	xorv[a]^=xorv[b];
	ch[a][0]=merge(ch[a][0],ch[b][0]);
	ch[a][1]=merge(ch[a][1],ch[b][1]);
	return a;
}
void addall(int u){
	swap(ch[u][0],ch[u][1]);
	if(ch[u][0]) addall(ch[u][0]);
	maintain(u);
}
int he[MAXN],ne[MAXN*2],to[MAXN*2],TOT;
inline void add(int x,int y){
	TOT++;ne[TOT]=he[x];he[x]=TOT;to[TOT]=y;
	TOT++;ne[TOT]=he[y];he[y]=TOT;to[TOT]=x;
}
int n,v[MAXN],val[MAXN];
int rt[MAXN];
long long ans;
void dfs(int u,int fa){
	for(int e=he[u];e;e=ne[e]){
		int v=to[e];
		if(v==fa) continue;
		dfs(v,u);
		addall(rt[v]);
		rt[u]=merge(rt[u],rt[v]);
	}
	ans+=xorv[rt[u]];
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout); 
	n=read();
	re int x;
	for(re int i=1;i<=n;i++)
		v[i]=read(),insert(rt[i],v[i],0);
	
	for(re int i=2;i<=n;i++){
		x=read();
		add(i,x);
	}
	dfs(1,0);
	printf("%lld\n",ans);
	return 0;
}
