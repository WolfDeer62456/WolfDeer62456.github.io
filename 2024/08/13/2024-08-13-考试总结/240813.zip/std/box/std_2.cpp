#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN=200005;
const ll INF=(1LL<<60)-1;
ll dp[MAXN];
int main()
{
    int n,C;
    scanf("%d%d",&n,&C);
    ll sum=0;
    vector<pair<int,int>> s(2*n);
    for(int i=0;i<n;i++)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        if(x<y)
        {
            s[2*i]={x,1};
            s[2*i+1]={y,-1};
        }
        else
        {
            s[2*i]={y,2};
            s[2*i+1]={x,-2};
        }
        sum+=abs(x-y);
    }
    sort(s.begin(),s.end());
    int cnt[2]={0,0},st=0;
    ll first=0;
    multiset<ll> slope;
    for(size_t i=0;i<s.size();i++)
    {
        auto& [x,t]=s[i];
        if(t>0)
        {
            cnt[t-1]++;
            first+=x;
            slope.insert(C-2LL*x);
        }
        else
        {
            cnt[-t-1]--;
            first+=C+x;
            slope.insert(-C-2LL*x);
            st--;
        }
        int c=max({cnt[0],cnt[1],(int)(i+1<s.size())});
        while(st<c)
        {
            first+=*slope.begin();
            slope.erase(slope.begin());
            st++;
        }
    }
    return 0*printf("%lld\n",sum+first);
}