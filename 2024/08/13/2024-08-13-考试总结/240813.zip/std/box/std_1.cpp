#pragma GCC optimize("Ofast,unroll-loops")
#include <bits/stdc++.h>
using namespace std;
int cover[300005][2],b[300005],x[150005],y[150005],l[300005],r[300005];
int main() {
    int T = 1;
    //cin >> T;
    while(T--) {
        int n,c,cnt=0;
        cin>>n>>c;
        for(int i=1;i<=n;i++){
            scanf("%d%d",&x[i],&y[i]);
            b[++cnt]=x[i],b[++cnt]=y[i];
        }
        sort(b+1,b+cnt+1),cnt=unique(b+1,b+cnt+1)-b-1;
        for(int i=1;i<=n;i++){
            x[i]=lower_bound(b+1,b+cnt+1,x[i])-b;
            y[i]=lower_bound(b+1,b+cnt+1,y[i])-b;
            if(x[i]<y[i]) cover[x[i]][0]++,cover[y[i]][0]--;
            else cover[y[i]][1]++,cover[x[i]][1]--;
        }
        int mx=0;
        long long ans=0;
        for(int i=1;i<cnt;i++) cover[i][0]+=cover[i-1][0],cover[i][1]+=cover[i-1][1];
        for(int i=1;i<cnt;i++) cover[i][0]=max({cover[i][0],cover[i][1],1}),ans+=1LL*cover[i][0]*(b[i+1]-b[i]),mx=max(mx,cover[i][0]);
        ans+=1LL*mx*c;
        vector <int> stk;
        for(int i=1;i<cnt;i++){
            while(stk.size()&&cover[stk.back()][0]<cover[i][0]) stk.pop_back();
            if(stk.size()) l[i]=stk.back();
            stk.push_back(i);
        }
        stk.clear();
        for(int i=cnt-1;i;i--){
            while(stk.size()&&cover[stk.back()][0]<=cover[i][0]) stk.pop_back();
            if(stk.size()) r[i]=stk.back();
            stk.push_back(i);
        }
        for(int i=1;i<cnt;i++){
            if(!l[i]||!r[i]||cover[l[i]][0]==cover[i][0]) continue;
            ans+=1LL*min(b[r[i]]-b[l[i]+1],c)*(min(cover[l[i]][0],cover[r[i]][0])-cover[i][0]);
        }
        printf("%lld\n",ans*2);
    }
    return 0;
}
