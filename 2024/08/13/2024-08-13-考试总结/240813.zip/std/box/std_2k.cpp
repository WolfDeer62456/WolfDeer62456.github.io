#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define cs const
#define pii pair<int,int>
#define fi first
#define se second
#define gc getchar
#define pb push_back
#define bg begin
#define int long long
inline int read(){
    char ch=gc();
    int res=0,f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
  inline ll readll(){
    char ch=gc();
    ll res=0,f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
template<typename tp>inline void chemx(tp &a,tp b){if(a<b)a=b;}
template<typename tp>inline void chemn(tp &a,tp b){if(a>b)a=b;}
cs int mod=998244353;
inline int add(int a,int b){return (a+b)>=mod?(a+b-mod):(a+b);}
inline int dec(int a,int b){return (a<b)?(a-b+mod):(a-b);}
inline int mul(int a,int b){static ll r;r=(ll)a*b;return (r>=mod)?(r%mod):r;}
inline void Add(int &a,int b){a=(a+b)>=mod?(a+b-mod):(a+b);}
inline void Dec(int &a,int b){a=(a<b)?(a-b+mod):(a-b);}
inline void Mul(int &a,int b){static ll r;r=(ll)a*b;a=(r>=mod)?(r%mod):r;}
inline int ksm(int a,int b,int res=1){for(;b;b>>=1,Mul(a,a))(b&1)&&(Mul(res,a),1);return res;}
inline int Inv(int x){return ksm(x,mod-2);}
inline int fix(ll x){x%=mod;return (x<0)?x+mod:x;}
cs int N=3005;
ll f[N][N];
int x[N],y[N];
int n,C;
cs ll inf=1e15;
struct node{
    int x,id,kd;
    node(int _x=0,int _id=0,int _kd=0):x(_x),id(_id),kd(_kd){}
    friend inline bool operator <(cs node &a,cs node &b){
        if(a.x!=b.x)return a.x<b.x;
        if(a.id!=b.id)return a.id<b.id;
        return a.kd<b.kd;
    }
}p[N+N];
signed main(){
    #ifdef Stargazer
    freopen("1.in","r",stdin);
    #endif
    n=read(),C=read();
    for(int i=1;i<=n;i++)x[i]=read(),y[i]=read(),p[i*2-1]=node(x[i],i,(x[i]<y[i])?0:3),p[i*2]=node(y[i],i,(x[i]<y[i])?2:1);
    memset(f,127/2,sizeof(f));
    sort(p+1,p+2*n+1);
    f[1][1]=C;
  //  for(int i=1;i<=2*n;i++)cout<<p[i].x<<" "<<p[i].id<<" "<<p[i].kd<<'\n';
    int el=0,er=0;
    for(int i=1;i<2*n;i++){
        if(p[i].kd==0){
            el++;
        }
        if(p[i].kd==1){
            er++;
        }assert(el>=0&&er>=0);
        if(p[i+1].kd==2){
            el--;
        }
        if(p[i+1].kd==3){
            er--;
        }assert(el>=0&&er>=0);
    //    cout<<"Now : "<<i<<" "<<el<<" "<<er<<'\n';
        for(int j=1;j<=i;j++)if(f[i][j]<inf){
     //       cout<<i<<" "<<j<<" "<<f[i][j]<<'\n';
            ll vl=f[i][j]+2ll*j*(p[i+1].x-p[i].x);
            if(p[i+1].kd==2){
                chemn(f[i+1][j],vl);
                if(j>er)chemn(f[i+1][j-1],vl+C);
            }
            if(p[i+1].kd==0){
                if(j>el)chemn(f[i+1][j],vl);
                chemn(f[i+1][j+1],vl+C);
            }
            if(p[i+1].kd==1){
                if(j>er)chemn(f[i+1][j],vl);
                chemn(f[i+1][j+1],vl+C);
            }
            if(p[i+1].kd==3){
                chemn(f[i+1][j],vl);
                if(j>el)chemn(f[i+1][j-1],vl+C);
            }
        }
 
    }
    ll ans=inf;
    for(int j=0;j<=2*n;j++)chemn(ans,f[2*n][j]+C*j);
    cout<<ans<<'\n';
}
