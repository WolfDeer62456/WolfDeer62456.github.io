#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int N=5e5+5;
int n,q,a[N],x,y,z,tim,dfn[N],id[N],R,A[N],B[N];
ll d[N],k;
pair<int,int>f[N][25];
vector<pair<int,int> >v[N];

void dfs(int x,int fa){
	f[dfn[x]=++tim][0]={dfn[fa],fa};
	for(auto p:v[x]){
		int y=p.first;
		if(y!=fa) d[y]=d[x]+p.second,dfs(y,x);
	}
}

int lca(int x,int y){
	if(x==y) return x;
	if((x=dfn[x])>(y=dfn[y])) swap(x,y);
	int k=__lg(y-(++x)+1);
	return min(f[x][k],f[y-(1<<k)+1][k]).second;
}
ll dis(int x,int y){return d[x]+d[y]-2*d[lca(x,y)];}

signed main(){
    freopen("tale.in", "r", stdin);
    freopen("tale.out", "w", stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]),id[i]=i;
	for(int i=1;i<n;i++)
		scanf("%d%d%d",&x,&y,&z),
		v[x].push_back({y,z}),v[y].push_back({x,z});
	dfs(1,0);
	for(int j=1;(1<<j)<=n;j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			f[i][j]=min(f[i][j-1],f[i+(1<<(j-1))][j-1]);
	sort(id+1,id+1+n,[](int x,int y){return a[x]<a[y];});
	R=n;
	for(int i=1;i<=n;i++)
		if(a[id[i]]!=i-1){R=i-1;break;}
	A[0]=B[0]=id[1];
	for(int i=1;i<R;i++){
		A[i]=A[i-1],B[i]=B[i-1];
		ll a=dis(A[i-1],id[i+1]),b=dis(B[i-1],id[i+1]);
		if(max(a,b)>dis(A[i],B[i])) A[i]=a>b?A[i-1]:B[i-1],B[i]=id[i+1];
	}
	while(q--){
		scanf("%d%lld",&x,&k);
		int l=0,r=R-1,ans=R;
		while(l<=r){
			int mid=(l+r)/2;
			if(max(dis(x,A[mid]),dis(x,B[mid]))>k) ans=mid,r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",ans);
	}
	return 0;
}
