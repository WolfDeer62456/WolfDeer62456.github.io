#include<bits/stdc++.h>
using namespace std;
#define cs const
#define pb push_back
#define pii pair<int,int>
#define ll long long
#define fi first
#define se second
#define bg begin
namespace IO{
#define gc getchar
inline int read(){
    char ch=gc();
    int res=0;bool f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
inline int readstring(char *s){
	int top=0;char ch=gc();
	while(isspace(ch))ch=gc();
	while(!isspace(ch)&&ch!=EOF)s[++top]=ch,ch=gc();
	s[top+1]='\0';return top;
}
 
}
using IO::read;
using IO::readstring;
 
cs int N=1000000;


int m,n,p,q;
pii t[N];
int c[N];
vector<int>op[N];

void solve(){
    n=read(),p=read(),q=read();
    for(int i=1;i<=n;i++){
        t[i].fi=read()+1,t[i].se=read()+1;
        if(t[i].fi>p||t[i].se>q){i--,n--;continue;}
        c[++m]=t[i].fi;
    }
    sort(c+1,c+m+1);
    m=unique(c+1,c+m+1)-c-1;
    ll ans=1ll*(p+1)*q*(q+1)/2+1ll*(q+1)*p*(p+1)/2;
    for(int i=1;i<=n;i++){
        t[i].fi=lower_bound(c+1,c+m+1,t[i].fi)-c;
        op[t[i].fi].pb(t[i].se);
    }
    ll sm=0;
    multiset<pii> st;
    st.insert(pii(0,0));
    st.insert(pii(q+1,1e9));
    int maxx=0;
    for(int i=1;i<=m;i++){
        sort(op[i].begin(),op[i].end());
        reverse(op[i].begin(),op[i].end());
        ans-=sm*(c[i]-c[i-1]);
        for(int x:op[i]){
            auto ip=st.lower_bound(pii(x,0));
            auto it=ip;it--;
            int vl=it->se+1;
            maxx=max(maxx,vl);
            sm-=1ll*it->se*(ip->fi-it->fi);
            pii now=pii(x,vl);
            sm+=1ll*it->se*(now.fi-it->fi);
            while(ip->se<=vl){
                auto nxt=ip;++nxt;
                sm-=1ll*ip->se*(nxt->fi-ip->fi);
                st.erase(ip);
                ip=nxt;
            }
            sm+=1ll*vl*(ip->fi-now.fi);
            st.insert(now);
        }
    }
    ans-=sm*(p+1-c[m]);
    cout<<ans<<'\n';
    for(int i=1;i<=m;i++)op[i].clear();
    m=0;
    
}

int main(){
    #ifdef Stargazer
    freopen("1.in","r",stdin);
    #endif
    int T=1;
    while(T--){
        solve();
    }return 0;
}
