#include<bits/stdc++.h>
using namespace std;
#define cs const
#define pb push_back
#define pii pair<int,int>
#define ll long long
#define fi first
#define se second
#define bg begin
namespace IO{
#define gc getchar
inline int read(){
    char ch=gc();
    int res=0;bool f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
inline int readstring(char *s){
	int top=0;char ch=gc();
	while(isspace(ch))ch=gc();
	while(!isspace(ch)&&ch!=EOF)s[++top]=ch,ch=gc();
	s[top+1]='\0';return top;
}
 
}
using IO::read;
using IO::readstring;
 
cs int N=1000000;
int n,p,q;
pii t[N];
#define lb(p) (p&(-p))
int tr[N];
void update(int p,int k){
    for(;p<=q;p+=lb(p))tr[p]=max(tr[p],k);
}
int query(int x,int res=0){
    for(;x;x-=lb(x))res=max(res,tr[x]);return res;
}

vector<int>op[N];
vector<pii>pos[N];
void solve(){
    n=read(),p=read(),q=read();
    for(int i=1;i<=n;i++){
        t[i].fi=read()+1,t[i].se=read()+1;
    }
    ll ans=1ll*(p+1)*q*(q+1)/2+1ll*(q+1)*p*(p+1)/2;
    for(int i=1;i<=n;i++){
        op[t[i].fi].pb(t[i].se);
    }
    ll sm=0;
    multiset<pii> st;
    memset(tr,0,sizeof(tr));
    for(int i=1;i<=p;i++){
        sort(op[i].begin(),op[i].end());
        reverse(op[i].begin(),op[i].end());
        for(int x:op[i]){
            int vl=query(x-1)+1;
            pos[vl].pb(pii(i,x));
            update(x,vl);
        }
    }
    for(int i=0;i<=n;i++){
        int lst=q+1;
        ll sm=0;
        for(pii x:pos[i]){
            sm+=1ll*(p-x.fi+1)*(lst-x.se);
            lst=x.se;
        }
        ans-=sm;
    }
    cout<<ans<<'\n';
    
}

int main(){
    #ifdef Stargazer
    freopen("1.in","r",stdin);
    #endif
    int T=1;
    while(T--){
        solve();
    }return 0;
}
