//gym 104976F
//https://codeforces.com/gym/104976/problem/F
#include<bits/stdc++.h>
#define LL long long
#define fr(x) freopen(#x".in","r",stdin);freopen(#x".out","w",stdout);
using namespace std;
namespace IO
{
	const int _Pu=2e7+5,_d=32;
	char buf[_Pu],obuf[_Pu],*p1=buf+_Pu,*p2=buf+_Pu,*p3=obuf,*p4=obuf+_Pu-_d;
	inline void fin()
	{
		memmove(buf,p1,p2-p1);
		int rlen=fread(buf+(p2-p1),1,p1-buf,stdin);
		if(p1-rlen>buf) buf[p2-p1+rlen]=EOF;p1=buf;
	}
	inline void fout(){fwrite(obuf,p3-obuf,1,stdout),p3=obuf;}
	inline LL rd()
	{
		if(p1+_d>p2) fin();LL x=0;
		for(;!isdigit(*p1);++p1);x=(*p1++-'0');
	    for(;isdigit(*p1);++p1) x=x*10+(*p1-'0');return x;
	}
	inline void wr(int x,char end='\n')
	{
		if(!x) return *p3++='0',*p3++=end,void();
		if(x<0) *p3++='-',x=-x;
		char sta[20],*top=sta;
		do{*top++=(x%10)+'0';x/=10;}while(x);
		do{*p3++=*--top;}while(top!=sta);(*p3++)=end;
	}
}using IO::rd;using IO::wr;
const int N=5e5+5;
int n,m,n0,tot,head[N],d[N],id[N],_id[N],mn[N][25],a[N],b[N];LL s[N];
struct node{int x,y;LL d;}c[N];
struct edge{int to,nex,w;}e[N<<1];
inline void add(int u,int v,int w)
{
	e[++tot]={v,head[u],w};head[u]=tot;
	e[++tot]={u,head[v],w};head[v]=tot;
}
inline int MN(int x,int y){return d[x]<d[y]?x:y;}
void dfs(int x,int fa)
{
	d[x]=d[mn[id[x]=++tot][0]=fa]+1;_id[tot]=x;
	for(int i=head[x];i;i=e[i].nex){int to=e[i].to;if(to!=fa) s[to]=s[x]+e[i].w,dfs(to,x);}
}
inline int lca(int u,int v)
{
	if(u==v) return u;u=id[u],v=id[v];u>v&&(swap(u,v),1);
	int t=__lg(v-(u++));return MN(mn[u][t],mn[v-(1<<t)+1][t]);
}
inline LL dis(int u,int v){return (u==-1||v==-1)?-1:s[u]+s[v]-(s[lca(u,v)]<<1);}
inline node hb(node x,int y)
{
	LL a=x.d,b=dis(x.x,y),c=dis(x.y,y),d=max({a,b,c});
	return (d==a)?x:((d==b)?(node){x.x,y,b}:(node){x.y,y,c});
}
int main()
{
	n=rd();m=rd();for(int i=1;i<=n;i++) a[i]=rd();
	for(int i=1,u,v,w;i<n;i++) u=rd(),v=rd(),w=rd(),add(u,v,w);tot=0;dfs(1,0);
	for(int i=1;i<=__lg(n);i++) for(int j=1;j+(1<<(i-1))<=n;j++) mn[j][i]=MN(mn[j][i-1],mn[j+(1<<(i-1))][i-1]);
	for(int i=1;i<=n;i++) if(a[i]<=n) b[a[i]]=i;
	for(int i=0;i<=n;i++) if(!b[i]){n0=i;break;}
	c[0]={b[0],-1,-1};for(int i=1;i<=n0;i++) c[i]=hb(c[i-1],b[i]);
	while(m--)
	{
		int x,l=0,r=n0,mid;LL L;node t;x=rd(),L=rd();
		while(l<r) t=c[mid=(l+r)>>1],(max(dis(t.x,x),dis(t.y,x))<=L)?l=mid+1:r=mid;
		wr(l);
	}
	return IO::fout(),0;
}