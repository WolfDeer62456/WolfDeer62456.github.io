#include<bits/stdc++.h>
using namespace std;
#define cs const
#define pb push_back
#define pii pair<int,int>
#define ll long long
#define y1 shinkle
#define fi first
#define se second
#define bg begin
namespace IO{
 
#define gc getchar
inline int read(){
    char ch=gc();
    int res=0;bool f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
 
}
using IO::read;
cs int N=1000005;
 
int n,m,k0,k1,ns,ms;
int ok[N],in[N];
vector<int> e[N],r[N];
 
void solve(){
    n=read(),m=read(),k0=read(),k1=read();
    for(int i=1;i<=k0;i++){
        int x=read()+1,y=read()+1+n;
        e[x].pb(y);
        r[y].pb(x);
    }
    for(int i=1;i<=k1;i++){
        int x=read()+1+n,y=read()+1;    
        e[x].pb(y);
        r[y].pb(x);
    }
    for(int i=1;i<=n+m;i++){
        sort(r[i].begin(),r[i].end());
        r[i].erase(unique(r[i].begin(),r[i].end()),r[i].end());
        sort(e[i].begin(),e[i].end());
        e[i].erase(unique(e[i].begin(),e[i].end()),e[i].end());
        in[i]=e[i].size();
    }
 
    //for(int i=1;i<=n+m;i++)assert(e[i].size()!=0);
    ns=read(),ms=read();
    for(int i=1;i<=ns;i++){
        ok[read()+1]=1;
    }
    for(int i=1;i<=ms;i++){
        ok[read()+n+1]=1;
    }
    queue<int> q;
 
    for(int i=1;i<=n+m;i++)if(!ok[i])q.push(i);
    while(q.size()){
        int x=q.front();q.pop();
        for(int y:r[x])if(ok[y]){
            if(y<=n){
                in[y]--;
                if(in[y]==0){
                    ok[y]=0;
                    q.push(y);
                }
            }
            else{
                ok[y]=0,q.push(y);
            }
        }
    }
    vector<int>ans0,ans1;
    for(int i=1;i<=n;i++)if(ok[i]==1)ans0.pb(i-1);
    for(int i=n+1;i<=n+m;i++)if(ok[i]==1)ans1.pb(i-n-1);
    cout<<ans0.size()<<" "<<ans1.size()<<'\n';
    for(int i=0;i<ans0.size();i++){
        cout<<ans0[i];
        if(i+1!=ans0.size())cout<<" ";
    }cout<<'\n';
    for(int i=0;i<ans1.size();i++){
        cout<<ans1[i];
        if(i+1!=ans1.size())cout<<" ";
    }cout<<'\n';
}
 
int main(){
    #ifdef Stargazer
    freopen("1.in","r",stdin);
    #endif
    int T=1;
    while(T--){
        solve();
    }return 0;
}
