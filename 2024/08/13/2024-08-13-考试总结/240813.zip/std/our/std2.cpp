#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <bitset>
#include <vector>
#include <cstring>
using namespace std;
const int N = 1000001;
int n, m, k0, k1, ns, ms;
vector<int> in[2][N];
int outdegree[2][N];
vector<int> d[2];
bool is_safe[2][N];
int main()
{
    scanf("%d %d %d %d", &n, &m, &k0, &k1);
    while (k0--) {
        int x, y;
        scanf("%d %d", &x, &y);
        in[1][y].push_back(x);
        outdegree[0][x]++;
    }
    while (k1--) {
        int x, y;
        scanf("%d %d", &x, &y);
        in[0][y].push_back(x);
        outdegree[1][x]++;
    }
    scanf("%d %d", &ns, &ms);
    while (ns--) {
        int x;
        scanf("%d", &x);
        is_safe[0][x] = true;
    }
    while (ms--) {
        int x;
        scanf("%d", &x);
        is_safe[1][x] = true;
    }
    for (int i = 0; i < n; i ++)
        if (!is_safe[0][i]) {
            d[0].push_back(i);
        }
    for (int i = 0; i < m; i ++)
        if (!is_safe[1][i]) {
            d[1].push_back(i);
        }
    int i0 = 0, i1 = 0;
    while (i0 < d[0].size() || i1 < d[1].size()) {
        if (i0 < d[0].size()) {
            int x = d[0][i0];
            i0 ++;
            for (auto y: in[0][x]) {
                if (is_safe[1][y]) {
                    d[1].push_back(y);
                    is_safe[1][y] = false;
                }
            }
        }
        if (i1 < d[1].size()) {
            int x = d[1][i1];
            i1 ++;
            for (auto y: in[1][x]) {
                outdegree[0][y] --;
                if (outdegree[0][y] == 0 && is_safe[0][y]) {
                    d[0].push_back(y);
                    is_safe[0][y] = false;
                }
            }
        }
    }
    printf("%d %d\n", n - d[0].size(), m - d[1].size());
    for (int i = 0; i < n; i ++)
        if (is_safe[0][i]) {
            printf("%d ", i);
        }
    printf("\n");
    for (int i = 0; i < m; i ++)
        if (is_safe[1][i]) {
            printf("%d ", i);
        }
    printf("\n");
    return 0;
}
