#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <queue>
using namespace std;
int Read() {
    int x = 0, f = 1; char ch = getchar();
    while(!isdigit(ch) && ch != '-')  ch = getchar();
    if(ch == '-')  f = -1, ch = getchar();
    while(isdigit(ch))  x = x * 10 + ch - '0', ch = getchar();
    return x * f;  
}
const int N = 3e5 + 5;
int first[N], nxt[N << 1], to[N << 1], tot;
void Add(int x, int y) {
    nxt[++tot] = first[x];
    first[x] = tot;
    to[tot] = y;
}
int n, m, x[N], y[N], a[N], b[N], d[N], du[N << 1], vis[N];
long long f[N << 1], ans[N << 1], val[N], pre[N], suf[N], Ans[N];
vector<int> edg[N << 1];

signed main() {
    freopen("race.in", "r", stdin);
    freopen("race.out", "w", stdout);
    n = Read(), m = Read();
    for (int i = 1; i <= n; i++)
        a[i] = Read(), b[i] = Read();
    for (int i = 1; i <= m; i++) {
        x[i] = Read(), y[i] = Read();
        Add(x[i], y[i]), Add(y[i], x[i]);
    }
    memset(d, -1, sizeof(d));
    queue<int> q;
    q.push(1);
    d[1] = 0;
    while(!q.empty()) {
        int u = q.front();
        q.pop();
        for (int e = first[u]; e; e = nxt[e]) {
            int v = to[e];
            if(d[v] == -1)
                d[v] = d[u] + 1, q.push(v);
        }
    }
    for (int i = 1; i <= m; i++) {
        if(d[x[i]] > d[y[i]])
            swap(x[i], y[i]);
        if(d[x[i]] == d[y[i]]) {
            edg[x[i] + n].push_back(y[i]);
            edg[y[i] + n].push_back(x[i]);
            ++du[x[i]], ++du[y[i]];
        }
        if(d[x[i]] + 1 == d[y[i]]) {
            edg[y[i] + n].push_back(x[i] + n);
            edg[y[i]].push_back(x[i]);
            ++du[x[i] + n], ++du[x[i]];
        }
    }
    for (int i = 1; i <= n; i++) {
        f[i] = a[i] - 1ll * (d[i] - 1) * b[i];
        f[i + n] = a[i] - 1ll * d[i] * b[i];
    }
    for (int i = 1; i <= 2 * n; i++) {
        ans[i] = -1e18;
        if(!du[i])
            q.push(i);
    }
    while(!q.empty()) {
        int u = q.front();
        q.pop();
        for(auto v : edg[u]) {
            f[v] = max(f[v], f[u]);
            ans[v] = max(ans[v], f[u]);
            --du[v];
            if(!du[v])
                q.push(v);
        }
    }
    int cnt = 0;
    long long maxn = -1e18;
    for (int e = first[1]; e; e = nxt[e])
        vis[to[e]] = 1;
    for (int i = 1; i <= n; i++) {
        if(!vis[i])
            maxn = max(maxn, a[i] - 1ll * (d[i] + 1) * b[i]);
        else
            val[++cnt] = a[i] - 2 * b[i], Ans[cnt] = ans[i];
    }
    pre[0] = suf[cnt + 1] = -1e18;
    for (int i = 1; i <= cnt; i++)
        pre[i] = max(pre[i - 1], val[i]);
    for (int i = cnt; i >= 1; i--)
        suf[i] = max(suf[i + 1], val[i]);
    for (int i = 1; i <= cnt; i++) {
        long long tmp1 = max(maxn, Ans[i]), tmp2 = max(pre[i - 1], suf[i + 1]);
        printf("%lld\n", max(tmp1, tmp2));
    }
    return 0;
}