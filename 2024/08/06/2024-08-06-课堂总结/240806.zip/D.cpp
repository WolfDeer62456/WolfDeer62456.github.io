#include <bits/stdc++.h>
using namespace std;
constexpr int N = 602;
int n, m, t, g, k, par[N], dp[N][4], a[N], b[N];
char ch[N][N];
int to[N];
vector<int> v[N];
void dfs(int x)
{
    if (v[x].size() == 0)
        return;
    for (int i = 0; i < 4; ++i)
        dp[x][i] = 0;
    for (unsigned i = 0; i < v[x].size(); ++i)
    {
        dfs(v[x][i]);
        for (int o = 0; o < 4; ++o)
        {
            int mini = dp[v[x][i]][o];
            for (int p = 0; p < 4; ++p)
            {
                mini = min(mini, dp[v[x][i]][p] + 1);
            }
            dp[x][o] += mini;
        }
    }
}
void solve()
{
    scanf("%d%d", &n, &m);
    if (n == 0)
    {
        printf("0\n");
        return;
    }
    for (int i = 1; i <= n; ++i)
        v[i].clear();
    for (int i = 2; i <= n; ++i)
    {
        scanf("%d", par + i);
        v[par[i]].push_back(i);
    }
    for (int i = 1; i <= m; ++i)
        scanf("%d%d", a + i, b + i);
    int ans = 0;
    for (int q = 0; q < k; ++q)
    {
        for (int i = 1; i <= m; ++i)
        {
            dp[a[i]][0] = dp[a[i]][1] = dp[a[i]][2] = dp[a[i]][3] = 0x3f3f3f3f;
            dp[a[i]][to[ch[b[i]][q]]] = 0;
        }
        dfs(1);
        ans += min(min(dp[1][0], dp[1][1]), min(dp[1][2], dp[1][3]));
    }
    printf("%d\n", ans);
}
int main()
{
    to['A'] = 0;
    to['C'] = 1;
    to['G'] = 2;
    to['T'] = 3;
    scanf("%d", &g);
    for (int i = 1; i <= g; ++i)
        scanf("%s", ch[i]);
    k = strlen(ch[1]);
    int t;
    scanf("%d", &t);
    while (t--)
        solve();
    return 0;
}