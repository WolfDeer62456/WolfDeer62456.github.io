#include <stdio.h>
#include <bits/stdc++.h>
#define yes printf("Yes\n")
#define no printf("No\n")
#define ll long long
#define all(x) x.begin(), x.end()
#define fastIO                   \
    ios::sync_with_stdio(false); \
    cin.tie(0);                  \
    cout.tie(0)
using namespace std;

// https://codeforces.com/gym/105239/problem/A
int main()
{

    ll dp[81][41]; // dp[i][j] : count of seq that start with i, lenth j

    for (int i = 1; i <= 80; i++)
        dp[i][1] = 1;
    for (int len = 2; len <= 40; len++)
    {
        for (int i = 1; i <= 81 - len; i++)
        {
            dp[i][len] = 0;

            if (i - 1 >= 1)
                dp[i][len] += dp[i - 1][len - 1];
            if (dp[i][len] > 1e18)
            {
                dp[i][len] = 1e18 + 1;
                continue;
            }

            dp[i][len] += dp[i][len - 1];
            if (dp[i][len] > 1e18)
            {
                dp[i][len] = 1e18 + 1;
                continue;
            }

            dp[i][len] += dp[i + 1][len - 1];
            if (dp[i][len] > 1e18)
            {
                dp[i][len] = 1e18 + 1;
                continue;
            }
        }
    }

    int n;
    ll k;
    cin >> n >> k;
    ll firnumber = 1;
    while (k >= dp[firnumber][n] && firnumber <= 40)
    {
        k -= dp[firnumber][n];
        firnumber++;
    }
    ll add = k / dp[firnumber][n];
    k %= dp[firnumber][n];
    firnumber += add;

    cout << firnumber << " ";
    while (--n)
    {
        ll nxtnumber = firnumber - 1;
        while (k >= dp[min(nxtnumber, 40ll)][n] && nxtnumber <= firnumber + 1)
        {
            k -= dp[min(nxtnumber, 40ll)][n];
            nxtnumber++;
        }
        cout << nxtnumber << " ";
        firnumber = nxtnumber;
    }

    return 0;
}