#include <bits/stdc++.h>
#define GO       \
    cin.tie(0);  \
    cout.tie(0); \
    ios::sync_with_stdio(0);
typedef long long ll;
using namespace std;
const int N = 3e5 + 5;
vector<int> adj[N];
int n, k;
int a[N];
set<int> s1, s2;
ll cur = 0;
ll ans = 0;

void DFS(int u)
{
    cur += a[u];
    s1.insert(a[u]);
    if (s1.size() > k)
    {
        cur -= *s1.begin();
        s2.insert(*s1.begin());
        s1.erase(s1.begin());
    }
    ans = max(ans, cur);
    for (int v : adj[u])
        DFS(v);
    if (s1.find(a[u]) != s1.end())
    {
        cur -= a[u];
        s1.erase(a[u]);
        if (s1.size() < k && s2.size())
        {
            cur += *s2.rbegin();
            s1.insert(*s2.rbegin());
            s2.erase(--s2.end());
        }
    }
    else
        s2.erase(a[u]);
}

int main()
{
    cin >> n >> k;
    int root;
    for (int i = 1; i <= n; i++)
    {
        int p;
        cin >> p >> a[i];
        if (!p)
            root = i;
        else
            adj[p].push_back(i);
    }
    DFS(root);
    cout << ans << endl;
    return 0;
}