#include <iostream>
using namespace std;
const int N = 1e5 + 10, P = 998244353;
long long n, k, f[N], g[N], fact[N];
void prework()
{
    fact[0] = 1;
    for (int i = 1; i <= max(n, k); i++)
        fact[i] = fact[i - 1] * i % P;
    g[1] = 1;
    for (int i = 2; i <= k; i++)
    {
        g[i] = fact[i];
        for (int j = 1; j < i; j++)
            g[i] = (g[i] - g[j] * fact[i - j] % P + P) % P;
    }
}
int main()
{
    cin >> n >> k;
    prework();
    f[k] = fact[k];
    for (int i = k; i <= n; i++)
        for (int j = 1; j <= k and i + j <= n; j++)
            f[i + j] = (f[i + j] + f[i] * g[j]) % P;
    cout << f[n] << endl;
    return 0;
}