#include <bits/stdc++.h>
using namespace std;
const int Mod = 998244353;
int n, kk, match[35][26];
char s[35];

struct matrix {
    int A[95][95];
    void Init() {
        for(int i = 1; i <= n * 3; i++)
            A[i][i] = 1;
    }
};

matrix operator * (matrix A, matrix B) {
    matrix C;
    memset(C.A, 0, sizeof(C.A));
    for(int i = 1; i <= n * 3; i++)
        for(int j = 1; j <= n * 3; j++)
            for(int k = 1; k <= n * 3; k++)
                C.A[i][j] = (C.A[i][j] + 1ll * A.A[i][k] * B.A[k][j]) % Mod;
    return C;
}
matrix qpow(matrix x, int k) {
    matrix res;
    res.Init();
    while(k) {
        if(k & 1)
            res = res * x;
        x = x * x;
        k >>= 1;
    }
    return res;
}

int main() {
    scanf("%s", s + 1);
    cin >> kk;
    n = strlen(s + 1);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < 26; j++) {
            if(j + 'a' == s[i + 1])
                match[i][j] = i + 1;
            else {
                for(int k = 1; k <= i; k++) {   //[1,k] & [i-k+2,i+1]
                    if(j + 'a' != s[k])
                        continue ;
                    int flag = 1;
                    for(int l = 1; l < k; l++)
                        if(s[l] != s[i - k + 1 + l])
                            flag = 0;
                    if(flag)
                        match[i][j] = k;
                }
            }
        }
    }
    int pos = 0;
    for(int i = 1; i < n; i++) { //[1,i] & [n-i+1,n]
        int flag = 1;
        for(int j = 1; j <= i; j++)
            if(s[j] != s[n - i + j])
                flag = 0;
        if(flag)
            pos = i;
    }
    matrix tmp;
    memset(tmp.A, 0, sizeof(tmp.A));
    for(int i = 0; i <= 2; i++) {
        for(int j = 0; j < n; j++) {
            for(int k = 0; k < 26; k++) {
                if(match[j][k] == n) {
                    if(i == 2)
                        continue ;
                    else
                        tmp.A[(i + 1) * n + pos + 1][i * n + j + 1]++;
                }
                else
                    tmp.A[i * n + match[j][k] + 1][i * n + j + 1]++;
            }
        }
    }
    tmp = qpow(tmp, kk);
    int ans = 0;
    for(int i = 1; i <= n; i++)
        ans = (ans + tmp.A[2 * n + i][1]) % Mod;
    cout << ans << endl;
}