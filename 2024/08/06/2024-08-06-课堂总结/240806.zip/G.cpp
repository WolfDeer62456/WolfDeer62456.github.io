#include <bits/stdc++.h>
using namespace std;
const int Mod = 998244353, inv2 = (Mod + 1) >> 1, N = 1e6 + 5;
int n, mul[N] = {1}, fac[N] = {1}, finv[N];
int qpow(int x, int k) {
    int res = 1;
    while(k) {
        if(k & 1)
            res = 1ll * res * x % Mod;
        x = 1ll * x * x % Mod;
        k >>= 1;
    }
    return res;
}
int C(int n, int m) {
    return 1ll * fac[n] * finv[m] % Mod * finv[n - m] % Mod;
}

int main() {
    for(int i = 1; i <= N - 5; i++) {
        mul[i] = 1ll * mul[i - 1] * (i - inv2 + Mod) % Mod;
        fac[i] = 1ll * fac[i - 1] * i % Mod;
    }
    finv[N - 5] = qpow(fac[N - 5], Mod - 2);
    for(int i = N - 5; i >= 1; i--)
        finv[i - 1] = 1ll * finv[i] * i % Mod;
    scanf("%d", &n);
    long long ans = 0;
    for(int i = 1; i <= n; i++) {
        int x;
        scanf("%d", &x);
        ans += 1ll * mul[i - 1] * mul[n - i] % Mod * C(n - 1, i - 1) % Mod * x % Mod * finv[n - 1] % Mod;
    }
    cout << ans % Mod << endl;
}