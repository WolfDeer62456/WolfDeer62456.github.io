#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int N = 1e3 + 3;

ll n, C, w[N], c[N];
ll dp[2][N][1 << 10];
vector<int> g[N];

void dfs(int u, int fa)
{
    dp[1][u][1 << c[u]] = w[u];
    for (auto v : g[u])
        if (v ^ fa)
        {
            dfs(v, u);
            for (int s = (1 << C) - 1; s; s--)
            {
                for (int t = s; t; t = (t - 1) & s)
                {
                    dp[1][u][s] = max(dp[1][u][s], dp[0][v][t] + dp[1][u][s ^ t]);
                    dp[0][u][s] = max(dp[0][u][s], dp[0][v][t] + dp[0][u][s ^ t]);
                    dp[0][u][s] = max(dp[0][u][s], dp[1][v][t] + dp[0][u][s ^ t]);
                }
            }
        }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    cin >> n >> C;
    for (int i = 1; i <= n; i++)
        cin >> w[i];
    for (int i = 1; i <= n; i++)
    {
        cin >> c[i];
        c[i]--;
    }
    for (int i = 1; i < n; i++)
    {
        int u, v;
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(1, 0);
    ll ans = 0;
    for (int s = 0; s < (1 << C); s++)
        ans = max({ans, dp[0][1][s], dp[1][1][s]});
    cout << ans << endl;
    return 0;
}