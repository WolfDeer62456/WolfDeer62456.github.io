#include<bits/stdc++.h>
using namespace std;
int rd(){
	int s=0; static char c;
	while(c=getchar(),c<48);
	do s=(s<<1)+(s<<3)+(c-48);
	while(c=getchar(),c>47);
	return s;
}

const int N=1e6+10;

int n,m;
struct Pii{ 
	int x,y; 
	Pii(){}
	Pii(int x,int y):x(x),y(y){}
};
Pii A[N],D[N];
int L[N],R[N];
Pii max(const Pii &x,const Pii &y) { return x.x!=y.x?(x.x>y.x?x:y):(x.y<y.y?x:y); }
void cmax(Pii &x,const Pii &y) { if(y.x>x.x || (y.x==x.x && y.y<x.y)) x=y; }
struct BIT{
	int s[N];
	void Init() {
		for(int i=1;i<=n;++i) s[i]=i&-i;
	}
	void Add(int p,int x) {
		while(p<=n) s[p]+=x,p+=p&-p;
	}
	int Que(int k) {
		int p=0;
		for(int i=19;~i;--i) if(p+(1<<i)<=n && k>s[p+(1<<i)]) k-=s[p+=1<<i];
		return p+1;
	}
} T;
struct BIT2{
	Pii s[N];
	void Init() { for(int i=1;i<=n;++i) s[i].x=-1; }
	void Add(int p,Pii x) { while(p<=n) cmax(s[p],x),p+=p&-p; }
	Pii Que(int p) {
		Pii res(0,1);
		while(p) cmax(res,s[p]),p-=p&-p;
		return res;
	}
} T2;

int main(){
	freopen("selection.in","r",stdin);
	freopen("selection.out","w",stdout);
	n=rd(),m=rd();
	T.Init(),T2.Init();
	for(int i=1;i<n;i++) A[i].y=rd();
	for(int i=1;i<=n;++i) L[i]=i-1,R[i]=i+1,D[i].y=i;
	R[0]=1,L[n+1]=n;
	while(m--) {
		int opt=rd();
		if(opt==1) {
			int l=rd(),r=rd()-l+1;
			for(int p=l=T.Que(l);p=R[p],--r;) {
				A[l].x=max(max(A[l].x,A[l].y),A[p].x);
				A[l].y=A[p].y;
				D[l]=max(D[l],D[p]);
				L[R[p]]=L[p],R[L[p]]=R[p];
				T.Add(p,-1);
			}
			D[l].x++,T2.Add(A[l].x,D[l]);
		} else printf("%d\n",T2.Que(rd()-1).y);
	}
}


