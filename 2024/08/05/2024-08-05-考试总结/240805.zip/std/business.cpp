#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef double db;
typedef pair <ll,ll> Pii;
#define reg register
#define mp make_pair
#define pb push_back
#define Mod1(x) ((x>=P)&&(x-=P))
#define Mod2(x) ((x<0)&&(x+=P))
#define rep(i,a,b) for(int i=a,i##end=b;i<=i##end;++i)
#define drep(i,a,b) for(int i=a,i##end=b;i>=i##end;--i)
template <class T> inline void cmin(T &a,T b){ ((a>b)&&(a=b)); }
template <class T> inline void cmax(T &a,T b){ ((a<b)&&(a=b)); }

template <class T=int> T rd() {
	T s=0; static char c;
	while(c=getchar(),c<48);
	do s=(s<<1)+(s<<3)+(c^'0');
	while(c=getchar(),c>47);
	return s;
}

bool Mbe;
const int N=1e6+10;

int n,m,a[N];
struct Edge{
	int to,nxt,w;
} e[N<<1];
int head[N],ecnt;
void AddEdge(int u,int v,int w) {
	e[++ecnt]=(Edge){v,head[u],w};
	head[u]=ecnt;
}

int ls[N],rs[N],dis[N]; Pii val[N];
void balance(int u) {
	if(dis[ls[u]]<dis[rs[u]]) swap(ls[u],rs[u]);
	dis[u]=dis[ls[u]]+1;
}
int merge(int u,int v) {
	if(!u || !v) return u|v;
	if(val[u]>val[v]) swap(u,v);
	rs[u]=merge(rs[u],v),balance(u);
	return u;
}
int pop(int u) { return merge(ls[u],rs[u]); }

int dfs(int u,int f,int fe) {
	int rt=0;
	for(int i=head[u];i;i=e[i].nxt) {
		int v=e[i].to;
		if(v==f) continue;
		rt=merge(rt,dfs(v,u,e[i].w));
	}
	val[u]=mp(fe,a[u]-fe),dis[u]=1;
	while(rt && (val[u].second<0 || val[rt].first<val[u].first)) {
		cmax(val[u].first,val[rt].first-val[u].second);
		val[u].second+=val[rt].second;
		rt=pop(rt);
	}
	if(val[u].second>0) rt=merge(u,rt);
	return rt;
}

Pii Q[N]; ll ans[N];

bool Med;
int main() {
	freopen("business.in","r",stdin);
	freopen("business.out","w",stdout);
	n=rd(),m=rd();
    assert(n >= 1 && n <= 1000000 && m >= 1 && m <= 200000);
	rep(i,1,n) {
		a[i]=rd();
        assert(a[i] >= 1 && a[i] <= 1000000000);
	}
	rep(i,2,n) {
		int u=rd(),v=rd(),w=rd();
        assert(u >= 1 && u <= n && v >= 1 && v <= n);
        assert(w >= 1 && w <= 1000000000);
		AddEdge(u,v,w),AddEdge(v,u,w);
	}
	int rt=dfs(1,0,0);
	rep(i,1,m) {
		Q[i].first=rd<ll>(),Q[i].second=i;
        assert(Q[i].first >= 0 && Q[i].first <= 1000000000000000ll);
	}
	sort(Q+1,Q+m+1);
	ll s=0;
	rep(i,1,m) {
		s+=Q[i].first-Q[i-1].first;
		while(rt && val[rt].first<=s) s+=val[rt].second,rt=pop(rt);
		ans[Q[i].second]=s;
	}
	rep(i,1,m) printf("%lld\n",ans[i]);
}




