#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include <cassert>
using namespace std;
#define M 105
#define ckmi(a,b) ((a>b)&&(a=b))
char dr[M];
int n,sk[M],dp[M][M];
void dfs(int l,int r){
    if(l>r)return;
    if(l==r){
        if(dr[l]=='('||dr[l]==')')putchar('('),putchar(')');
        if(dr[l]=='['||dr[l]==']')putchar('['),putchar(']');
        return;
    }
    if(((dr[l]=='('&&dr[r]==')')||(dr[l]=='['&&dr[r]==']'))&&dp[l+1][r-1]==dp[l][r]){
        printf("%c",dr[l]);
        dfs(l+1,r-1);
        printf("%c",dr[r]);
        return;
    }
    for(int i=l;i<r;++i)if(dp[l][i]+dp[i+1][r]==dp[l][r]){
        dfs(l,i),dfs(i+1,r);return;
    }
}
int main(){
	freopen("bracket.in","r",stdin);
	freopen("bracket.out","w",stdout);
    scanf("%s",dr+1);
    n=strlen(dr+1);
    assert(n<=100);
    for(int i=1;i<=n;++i) if(dr[i]!='(' && dr[i]!=')' && dr[i]!='[' && dr[i]!=']') return cerr<<"UNDEFINED CHARACTER",0;
    for(int i=n;i>=1;--i){
        dp[i][i]=1;
        for(int j=i+1;j<=n;++j){
            dp[i][j]=1e9;
            if((dr[i]=='('&&dr[j]==')')||(dr[i]=='['&&dr[j]==']'))ckmi(dp[i][j],dp[i+1][j-1]);
            for(int k=i;k<j;++k)ckmi(dp[i][j],dp[i][k]+dp[k+1][j]);
        }
    }
    dfs(1,n);
}
