#include<bits/stdc++.h>
using namespace std;
const int MAXN = 105 ;
const int MAXM = 2012 ;
int dp[MAXN][MAXM] ;
const int mod = 1e9 + 7 ;
inline void Add(int &a,int b){((a+=b)>=mod)&&(a-=mod);}
int n ;
int a[MAXN] ;
const int D = 1000 ;  
void push(int i,int j){
	if(!dp[i][j]) return ; 
	set<int> s ;
	if(j+a[i]!=D) s.emplace(j+a[i]-D);
	for(int p=i+1;p<=n;p++){
		for(auto v : s)
			Add(dp[p][v+D],dp[i][j]);
		
		if(j+a[i]==D&&a[p]!=0) s.emplace(a[p]);	
	}
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	dp[0][D]=1 ;
	for(int i=0;i<n;i++)
		for(int j=-1000;j<=1000;j++){
			//if(j==0) continue ; 
			int now = j + D ;
			push(i,now);
		}
	int ans = 1 ;
	for(int i=1;i<=n;i++) for(int j=0;j<=2000;j++) Add(ans,dp[i][j]);
	cout<<ans;
	return 0;
} 
