#include<bits/stdc++.h>
#define int long long 
using namespace std;
const int mod = 1e9 + 7 ;
inline void Add(int &a,const int &b){((a+=b)>=mod)&&(a-=mod);}
inline void Dec(int &a,const int &b){((a-=b)<0)&&(a+=mod);}
inline int D(const int &x){return x<0?x+mod:x;}
inline int A(const int &x){return x>=mod?x-mod:x;}
struct Matrix{
	int g[12][12];
	Matrix(){
		memset(g,0,sizeof(g));
	}
	
	Matrix operator * (const Matrix &x)const{
		Matrix res ;
		for(int i=0;i<12;i++){
			for(int k=0;k<12;k++){
				if(g[i][k])
				for(int j=0;j<12;j++) Add(res.g[i][j],g[i][k]*x.g[k][j]%mod);				
			}
		}
		return res ;
	}
}I;
Matrix mol(Matrix x,int y){
	Matrix res = I , tmp  = x ;
	while(y){
		if(y&1ll) res=res*tmp;
		tmp=tmp*tmp;y>>=1;
	}
	return res ;
}
namespace Zheng{
	inline int num(const int &x,const int &y){return x*3+y;}
	Matrix Base,st;
	inline void Ad(const int &x,const int &y,const int &a,const int &b){
		int to = num(x,y) , from=num(a,b) ;
		Base.g[to][from]++;
	}
	Matrix Feb,F0;
	int dp(int n){
		Matrix tmp = mol(Base,n)*st;
		return (tmp.g[num(0,0)][0]+tmp.g[num(1,1)][0]+tmp.g[num(2,1)][0]+tmp.g[num(3,2)][0])%mod;
	}
	int S(int n){
		if(n==-1) return 0;
		if(n==0) return 1;
		if(n==1) return 4;
		Matrix res = mol(Feb,n-1)*F0;
		return (res.g[3][0]+res.g[2][0]*2)%mod;
	}
	void solve(){
		st.g[num(3,0)][0]=1;
			for(int j=0;j<3;j++){
				if(j>=2){Ad(0,j,0,j-2);Ad(3,j,0,j-2);} 
				if(j>=1){
					Ad(0,j,1,j-1),Ad(0,j,2,j-1);Ad(1,j,0,j-1);Ad(2,j,0,j-1);Ad(3,j,1,j-1),Ad(3,j,2,j-1);
				}
				Ad(0,j,3,j);Ad(1,j,2,j);Ad(2,j,1,j);Ad(3,j,0,j),Ad(3,j,3,j);
			}
		int T,n;
		F0.g[0][0]=F0.g[1][0]=F0.g[2][0]=1;
		F0.g[3][0]=2;
							Feb.g[0][1]=1;
			
		Feb.g[1][0]=1;		Feb.g[1][1]=1;
												Feb.g[2][3]=1;
		Feb.g[3][0]=Feb.g[3][1]=Feb.g[3][2]=    Feb.g[3][3]=1;
		cin>>T;
		while(T--){
			cin>>n;
			int res = dp(n);
			Dec(res,S(n-1));
			cout<<res<<"\n";
		}
	}
}
signed main(){
	freopen("mad.in","r",stdin);
	freopen("mad.out","w",stdout);
	for(int i=0;i<12;i++) I.g[i][i]=1;
	Zheng::solve();
	return 0;
}
