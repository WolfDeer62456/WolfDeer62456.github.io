#include<bits/stdc++.h>
#define int long long 
#define fi first
#define mp make_pair
#define se second
using namespace std;
const int mod = 1e9 + 7 ;
inline int read(){
	int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return w*s;
}
inline int mol(int x,int y){
	int res =1 , tmp =x ;
	while(y){
		if(y&1ll) res=res*tmp%mod;
		tmp=tmp*tmp%mod;y>>=1;
	}
	return res ;
}
inline int D(const int &x){return x<0?x+mod:x;}
inline int S(int t){
	return mol(D(1-t),mod-2);
}
const int MAXN = 501234 ;
struct node{
	int L0,L1,R0,R1;
};
node operator +  (node A, node B){
	node res ;
	res.L0=A.L0*B.L0%mod*S(B.L1*A.R1%mod)%mod;
	res.L1=(A.L0*B.L1%mod*A.R0%mod*S(B.L1*A.R1%mod)%mod+A.L1)%mod;
	swap(A,B);
	swap(B.L0,B.R0),swap(B.L1,B.R1);
	swap(A.L0,A.R0),swap(A.L1,A.R1);
	res.R0=A.L0*B.L0%mod*S(B.L1*A.R1%mod)%mod;
//	printf("%lld %lld %lld %lld\n",A.L0,B.L1,A.R0,S(B.L1*A.R1%mod)); 
	res.R1=(A.L0*B.L1%mod*A.R0%mod*S(B.L1*A.R1%mod)%mod+A.L1)%mod;
	return res ;
} 
int n;int I;
node dat[MAXN];
signed main(){
	freopen("light.in","r",stdin);
	freopen("light.out","w",stdout);
	n=read();
	I=mol(100,mod-2);
	for(int i=1;i<=n;i++){
		dat[i].L0=dat[i].R0=read()*I%mod;
		dat[i].L1=dat[i].R1=read()*I%mod;
	} 
	node tmp=(node){1,0,1,0};
	for(int i=1;i<=n;i++){
		tmp=tmp+dat[i];
	//	printf("%lld %lld %lld %lld\n",tmp.L0,tmp.L1,tmp.R0,tmp.R1);
	} 
	printf("%lld\n",tmp.L0);
	return 0;
}





