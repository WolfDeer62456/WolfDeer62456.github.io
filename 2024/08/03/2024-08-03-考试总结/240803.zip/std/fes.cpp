#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return w*s;
}
const int MAXN = 612 ;
int dis[MAXN][MAXN];
inline void Min(int &a,const int &b){(a>b)&&(a=b);}
int n,M1,M2;
vector<int> e[MAXN];
int dfn[MAXN],low[MAXN],T,co[MAXN],cnt;
vector<int> scc[MAXN];
int stk[MAXN],tp;
void tarjan(int u){
	dfn[u]=low[u]=++T;
	stk[++tp]=u;
	for(auto v:e[u]){
		if(!dfn[v]){
			tarjan(v);
			Min(low[u],low[v]);
		}
		else if(!co[v]) Min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u]){
		cnt++;scc[cnt].emplace_back(u);co[u]=cnt;
		while(stk[tp]!=u){
			co[stk[tp]]=cnt;
			scc[cnt].emplace_back(stk[tp]);
			tp--;
		}tp--;
	}
}
int main(){
	freopen("fes.in","r",stdin);
	freopen("fes.out","w",stdout);
	memset(dis,0x3f3f3f3f,sizeof(dis));
	n=read(),M1=read(),M2=read();
	int x,y;
	for(int i=1;i<=n;i++) dis[i][i]=0;//**
	while(M1--){
		x=read(),y=read();
		e[x].emplace_back(y);
		e[y].emplace_back(x);
		Min(dis[x][y],1);
		Min(dis[y][x],-1);
	}
	while(M2--){
		x=read(),y=read();
		e[y].emplace_back(x);
		Min(dis[y][x],0);
	}
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++) Min(dis[i][j],dis[i][k]+dis[k][j]);
		
	for(int i=1;i<=n;i++)
		if(dis[i][i]<0){
			printf("NIE\n");return 0;
		} 
	for(int i=1;i<=n;i++) if(!dfn[i]) tarjan(i);
	int ans = cnt ;
	for(int i=1;i<=cnt;i++){
		int tmp = 0 ;
		for(auto x:scc[i]) for(auto y:scc[i]) tmp=max(tmp,dis[x][y]);
		ans+=tmp;
	}
	cout<<ans;
	return 0;
}
