#include <bits/stdc++.h>
using namespace std;
 
using i64 = long long;
 
int __OneWan_2024 = [](){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    return 0;
}();
int tr[1000005][2], tot, cnt[1000005][2];
double f[1005][1005];
void insert(string str) {
    int p = 0;
    int len = str.size();
    for (int i = 0 ; i < len ; i++) {
        int k = str[i] - '0';
        if (!tr[p][k]) tr[p][k] = ++tot;
        cnt[p][k]++;
        p = tr[p][k];
    }
}
int main() {
    freopen("type.in", "r", stdin);
    freopen("type.out", "w", stdout);
    int n, m;
    double p;
    cin >> n >> m >> p;
    for (int i = 1 ; i <= n ; i++) {
        string str;
        cin >> str;
        insert(str);
    }
    double q = 1 - p;
    f[0][0] = 1;
    for (int i = 1 ; i <= n ; i++) {
        f[i][0] = f[i - 1][0] * p;
        f[0][i] = f[0][i - 1] * p;
    }
    for (int i = 1 ; i <= n ; i++) {
        for (int j = 1 ; j <= n ; j++) {
            f[i][j] = p * max(f[i - 1][j], f[i][j - 1]) + q * min(f[i - 1][j], f[i][j - 1]);
        }
    }
    double ans = 1;
    for (int i = 0 ; i <= tot ; i++) {
        // cout << cnt[i][0] << " " << cnt[i][1] << " " << f[cnt[i][0]][cnt[i][1]] << "\n";
        ans *= f[cnt[i][0]][cnt[i][1]];
    }
    cout << fixed << setprecision(12) << ans << "\n";
    return 0;
}