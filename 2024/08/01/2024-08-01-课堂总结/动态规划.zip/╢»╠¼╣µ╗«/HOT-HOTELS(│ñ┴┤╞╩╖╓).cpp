#include<bits/stdc++.h>
#define int long long 
using namespace std;
inline int read(){
	int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return w*s;
}
const int MAXN = 5010 ;
int he[MAXN],ne[MAXN*2],to[MAXN*2],tot;
inline void add(int x,int y){
	tot++;ne[tot]=he[x];he[x]=tot;to[tot]=y;
	tot++;ne[tot]=he[y];he[y]=tot;to[tot]=x;
}
int n,md[MAXN],hson[MAXN];
void dfs1(int u,int fa){
	for(int e=he[u];e;e=ne[e]){
		int v=to[e];
		if(v==fa) continue ;
		dfs1(v,u);
		if(md[v]>md[hson[u]]) hson[u]=v;
	}
	md[u]=md[hson[u]]+1;
}
struct node{
	vector<int> tmp;int D;
	void SIZ(int x){tmp.resize(x*3+5);D=x;}//Ҫ��3����
}f[MAXN],g[MAXN]; //**
#define f(x,y) f[x].tmp[(y)+f[x].D]
#define g(x,y) g[x].tmp[(y)+g[x].D]
int ans ;
void dfs(int u,int fa,int dep){
	if(hson[u]) dfs(hson[u],u,dep);
	else f[u].SIZ(dep),g[u].SIZ(dep);
	f(u,0)=1;ans+=g(u,0);
	for(int e=he[u];e;e=ne[e]){
		int v=to[e];if(v==fa||v==hson[u]) continue ;
		dfs(v,u,md[v]);
		for(int j=0;j<md[v];j++){
			if(j) ans+=f(u,j-1)*g(v,j);
			ans+=g(u,j+1)*f(v,j); 
		} 
		for(int j=0;j<md[v];j++){
			g(u,j+1)+=f(u,j+1)*f(v,j);
			if(j) g(u,j-1)+=g(v,j);
			f(u,j+1)+=f(v,j);
		}
	}
	if(hson[fa]==u) f[fa]=move(f[u]),f[fa].D--,g[fa]=move(g[u]),g[fa].D++;
}
signed main(){
	n=read();
	int x,y;
	for(int i=1;i<n;i++) x=read(),y=read(),add(x,y);
	dfs1(1,0);
	dfs(1,0,md[1]);
	printf("%lld\n",ans);
	return 0;
}
