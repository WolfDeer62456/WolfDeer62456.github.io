#include<bits/stdc++.h>
#define re register 
using namespace std;
inline int read(){
	re int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return w*s;
} 
const int MAXN = 5678; 
int dp[MAXN][MAXN],n,a[MAXN];
int pos0[MAXN],pos1[MAXN],num0=0,num1=0;
int main(){
	n=read();
	memset(dp,0x3f3f3f3f,sizeof(dp));
	memset(dp[0],0,sizeof(dp[0]));
	for(re int i=1;i<=n;i++){
		a[i]=read();
		if(a[i]==0) pos0[++num0]=i;
		else pos1[++num1]=i;
	}
	for(re int i=1;i<=num1;i++){
		for(re int j=i;j<=num0;j++){
			dp[i][j]=min(dp[i][j-1],dp[i-1][j-1]+abs(pos0[j]-pos1[i]));
		}
	}
	printf("%d\n",dp[num1][num0]);
	return 0;
}

