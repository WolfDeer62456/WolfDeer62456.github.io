#include<bits/stdc++.h>
#define re register 
#define lson (k<<1)
#define rson ((k<<1)|1)
#define fi first
#define se second
#define mp make_pair
using namespace std;
inline int read(){
	re int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return w*s;
}
const int MAXN = 305678 ;
int l[MAXN],r[MAXN];
vector<int> e[MAXN];
int n,m;
int Hash[MAXN*2],cnt;
pair<int,int> f[MAXN];

pair<int,int> dat[MAXN*8];
pair<int,int> add[MAXN*8];
inline void Add(int k,pair<int,int> v){
	if(v>dat[k]) dat[k]=v;
	add[k]=v;
}

void pushdown(int k){
	if(!add[k].se) return ;
	Add(lson,add[k]);
	Add(rson,add[k]);
	add[k]=mp(0,0);
}
inline void update(int k){
	dat[k]=(dat[lson]>dat[rson]?dat[lson]:dat[rson]); 
}
void modify(int k,int l,int r,int x,int y,pair<int,int> v){
	if(x<=l&&r<=y){
		Add(k,v);return ;
	}	
	int mid=(l+r)>>1;
	pushdown(k);
	if(x<=mid) modify(lson,l,mid,x,y,v);
	if(y>mid) modify(rson,mid+1,r,x,y,v);
	update(k);
}
inline pair<int,int> MAX(pair<int,int> x,pair<int,int> y){
	return x>y?x:y;
}
pair<int,int> query(int k,int l,int r,int x,int y){
	if(x<=l&&r<=y) return dat[k];
	int mid=(l+r)>>1;
	pushdown(k);
	pair<int,int> res=mp(0,0);
	if(x<=mid) res=query(lson,l,mid,x,y);
	if(y>mid) res=MAX(res,query(rson,mid+1,r,x,y));
	return res;
}
int Last[MAXN];
pair<int,int> Ask(int x){
	pair<int,int> res;
	for(re int i=0;i<(int)e[x].size();i++) res=MAX(res,query(1,1,cnt,l[e[x][i]],r[e[x][i]]));
	return res; 
}
void ADD(int x){
	for(re int i=0;i<(int)e[x].size();i++) modify(1,1,cnt,l[e[x][i]],r[e[x][i]],f[x]);
}
bool b[MAXN];
void Print(int x){
	if(!x) return ;
	b[x]=true;
	Print(Last[x]);
}
int main(){
	n=read(),m=read();re int x;
	for(int i=1;i<=m;i++){
		x=read(),l[i]=read(),r[i]=read();
		Hash[++cnt]=l[i],Hash[++cnt]=r[i];
		e[x].push_back(i);
	}
	sort(Hash+1,Hash+cnt+1);
	cnt=unique(Hash+1,Hash+cnt+1)-Hash-1;
	for(re int i=1;i<=m;i++){
		l[i]=lower_bound(Hash+1,Hash+cnt+1,l[i])-Hash;
		r[i]=lower_bound(Hash+1,Hash+cnt+1,r[i])-Hash;
	}
	int Max = 0;
	for(int i=1;i<=n;i++){
		pair<int,int> now=Ask(i);
		Last[i]=now.se;
		f[i]=mp(now.fi+1,i);
	//	printf("f[%d]=(%d,%d)\n",i,f[i].fi,Last[i]);
		ADD(i);
		if(f[i].fi>f[Max].fi) Max=i;
	}
	printf("%d\n",n-f[Max].fi);
	Print(Max);
	for(re int i=1;i<=n;i++) if(!b[i]) printf("%d ",i);
	return 0;
}





