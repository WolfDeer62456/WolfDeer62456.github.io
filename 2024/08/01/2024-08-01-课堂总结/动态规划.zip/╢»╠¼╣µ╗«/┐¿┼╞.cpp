#include<bits/stdc++.h>
using namespace std;
namespace IO{
	const int sz = 1<<20 ;
	char a[sz+5],*p1=a,*p2=a;
	inline char gc(){
		return p1==p2?(p2=(p1=a)+fread(a,1,sz,stdin),p1==p2?EOF:*p1++):*p1++;		
	}
	template<class T> inline void gi(T &x){
		x=0;char c=gc();
		while(c<'0'||c>'9') c=gc();
		while(c>='0'&&c<='9') x=x*10+(c-'0'),c=gc(); 
	}
}
using IO::gi;
const int MAXM = 2022 ;
const int NUM = 733 ;
const int mod = 998244353 ; 
int f[NUM][1<<13];
//2 3 5 7 11 13 17 19 23 29 31 37 41 
const int p[13]={2,3,5,7,11,13,17,19,23,29,31,37,41};
const int MAXN = 1001234; 
int num[MAXM] , M[MAXN] ;
inline void Add(int &a,int b){((a+=b)>=mod)&&(a-=mod);}
inline void Dec(int &a,int b){((a-=b)<0)&&(a+=mod);}
int n,m; 
int F[1<<13] , G[1<<13] ;
const int up = (1<<13)-1; 
void FWT(int a[],bool opt){
	for(int i=1;i<=up;i<<=1)
		for(int j=0;j<=up;j++) if(!(j&i)) opt?Add(a[j|i],a[j]):Dec(a[j|i],a[j]);
}
inline int mol(int x,int y){
	long long res = 1 , tmp =x  ;
	while(y){
		if(y&1ll) res=res*tmp%mod;
		tmp=tmp*tmp%mod;y>>=1;
	}
	return res ;
}
int id[MAXM] ;bool Not[MAXM];int cnt = 0 ;int t[MAXM];
int T[MAXM];
inline int D(int x){return x<0?x+mod:x;} 
void Ad(int a[],int now){
	for(int i=up;i>=0;i--)
		Add(a[i|T[now]],1ll*a[i]*D(M[num[now]]-1)%mod);
}
int pri[MAXN] ;
int main(){
//	freopen("in.txt","r",stdin);
	gi(n);
	int x;
	for(int i=1;i<=n;i++) gi(x),num[x]++;
	M[0]=1;
	for(int i=1;i<=n;i++) M[i]=M[i-1]*2%mod ; 
//	printf("??\n");
	for(int i=2;i<=2000;i++){
		if(Not[i]) continue ;
		for(int j=i*i;j<=2000;j+=i) Not[j]=true ;
	}
	for(int i=2;i<=2000;i++) if(!Not[i]&&i>41) id[i]=++cnt,t[cnt]=i;
	for(int i=2;i<=2000;i++){
		for(int j=0;j<13;j++) if(!(i%p[j])) T[i]|=(1<<j);
	}
	for(int i=1;i<=cnt;i++){ 
		bool flag = false ; 
		int now = t[i] ;f[i][0]=1; 
		for(int j=now;j<=2000;j+=now) if(num[j]) Ad(f[i],j),flag=true; 
		if(flag) FWT(f[i],1);
		if(flag) for(int j=0;j<=up;j++) f[i][j]=1ll*D(f[i][j]-1)*mol(f[i][j],mod-2)%mod;
	}
	F[0]=1 ;
	for(int i=1;i<=2000;i++) if(num[i]) Ad(F,i);
//	printf("??\n");
	FWT(F,1);
	gi(m);int k ;
	memcpy(G,F,sizeof(F));
	while(m--){
		gi(k);int S = 0 ;
		for(int i=1;i<=k;i++){
			gi(pri[i]);
			if(pri[i]>41){
				int tt = id[pri[i]] ;
				for(int j=0;j<=up;j++) F[j]=1ll*F[j]*f[tt][j]%mod ;
			}
			else for(int k=0;k<13;k++) if(pri[i]==p[k]) S|=(1<<k);
		} 
		FWT(F,false);
		int ans = 0 ;
		for(int i=0;i<=up;i++) if((i&S)==S) Add(ans,F[i]);
		cout<<ans<<"\n";  
		memcpy(F,G,sizeof(F));
	}
	return 0;
}
