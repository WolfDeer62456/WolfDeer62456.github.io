#include<bits/stdc++.h>
#define re register 
#define int long long 
using namespace std;
inline int read(){
	re int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return w*s;
}
const int MAXN = 345 ;
const int d = 101 ;
const int MAXM = 2345; 
const int mod=998244353 ;
int dp[MAXN][MAXM],f[MAXN][MAXM],ans;
int a[MAXN][MAXM],n,m,Sum[MAXN];
signed main(){
	n=read(),m=read();
	for(re int i=1;i<=n;i++){
		for(re int j=1;j<=m;j++) a[i][j]=read(),Sum[i]=(Sum[i]+a[i][j])%mod;
	}
	ans=0;memset(dp,0,sizeof(dp));dp[0][0]=1;
	for(re int i=1;i<=n;i++){
		dp[i][0]=1;
		for(re int j=1;j<=n;j++){
			dp[i][j]=(Sum[i]*dp[i-1][j-1]%mod+dp[i-1][j])%mod;
		//	printf("dp[%lld][%lld]=%lld\n",i,j,dp[i][j]);
		}
	}
	for(re int i=1;i<=n;i++) ans=(ans+dp[n][i])%mod;
	for(re int i=1;i<=m;i++){
		memset(f,0,sizeof(f));
		f[0][d]=1;
		for(re int j=1;j<=n;j++){
			for(re int k=1;k<=2*d;k++){
				f[j][k]=(f[j-1][k]+f[j-1][k-1]*a[j][i]%mod+f[j-1][k+1]*(Sum[j]-a[j][i])%mod)%mod;
			}
		}
		for(re int j=d+1;j<=2*d;j++){
			ans=(ans-f[n][j])%mod;
		}
	}
	printf("%lld\n",(ans%mod+mod)%mod);
	return 0;
}
