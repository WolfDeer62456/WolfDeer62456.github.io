#include<bits/stdc++.h>
#define int long long 
using namespace std;
inline int read(){
	int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return w*s;
} 
const int MAXN = 18 ;
int n,m;
int b[MAXN][MAXN];
vector<int> e[MAXN];
int up ;
int f[MAXN][MAXN] ;
int ban[MAXN] ;
int g;
void dfs(int u,int fa){
	for(auto x:e[u]){
		if(x==fa) continue ;
		dfs(x,u);
	}
	for(int i=1;i<=n;i++){
		if(ban[i]) continue ;
		f[u][i]=1;
		for(auto x:e[u]){
			if(x==fa) continue ;
			g=0;
			for(int j=1;j<=n;j++){
				if(ban[j]||(!b[i][j])) continue ;
		//		printf("(%lld,%lld)-(%lld,%lld)\n",u,i,x,j);
				g+=(f[u][i]*f[x][j]);
			}
			f[u][i]=g;if(!g) break;
		}
	//	printf("f[%lld][%lld]=%lld\n",u,i,f[u][i]);
	}
}
signed main(){
	n=read(),m=read();
	int x,y;
	for(int i=1;i<=m;i++){
		x=read(),y=read();
		b[x][y]=b[y][x]=1;
	}
	for(int i=1;i<n;i++){
		x=read(),y=read();
		e[x].emplace_back(y);
		e[y].emplace_back(x);
	}
	up=(1<<n)-1;
	int Ans = 0 ;
	for(int i=1;i<=up;i++){
		int k = 0 ;
		memset(ban,0,sizeof(ban));
		for(int j=0;j<n;j++){
			if(i&(1<<j)) k++;//**
			else ban[j+1]=1;
		}
		memset(f,0,sizeof(f));
		dfs(1,0);int ans = 0;
		for(int j=1;j<=n;j++) ans+=f[1][j];
	//	printf("ans=%lld\n",ans);
		if((n-k)&1) Ans-=ans;
		else Ans+=ans;
	}
	printf("%lld\n",Ans);
	return 0;
}
