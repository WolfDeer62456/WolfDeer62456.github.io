#include<bits/stdc++.h>
#define re register
using namespace std;
const int MAXN = 100 ;
const int MAXT = 3000;
int f[MAXN][MAXT];
int g[MAXN][MAXN][MAXN];
int n,m,t;
char s[100];
int sum[MAXN],a[MAXN];
int main(){
	scanf("%d%d%d",&n,&m,&t);
	for(re int i=1;i<=n;i++){
		scanf("%s",s);
		int l=strlen(s);
		for(re int j=1;j<=l;j++) a[j]=s[j-1]-'0',sum[j]=sum[j-1]+a[j];
		for(re int j=1;j<=m;j++){
			for(re int k=1;k<=m;k++){
				for(re int q=j-1;q<k;q++){
					g[i][j][k]=max(g[i][j][k],g[i][j-1][q]+max(sum[k]-sum[q],(k-q)-(sum[k]-sum[q])));
				}
			}
		}
	}
	for(re int i=1;i<=n;i++){
		for(re int j=1;j<=t;j++){
			for(re int k=0;k<=min(j,m);k++)
			f[i][j]=max(f[i][j],f[i-1][j-k]+g[i][k][m]); 
		}
	} 
	int ans = 0;
	for(re int i=1;i<=t;i++) ans=max(ans,f[n][i]);
	printf("%d\n",ans);
	return 0;
	
}
