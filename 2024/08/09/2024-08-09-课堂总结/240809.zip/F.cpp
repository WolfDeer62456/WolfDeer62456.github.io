#pragma GCC diagnostic error "-std=c++11"
#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
#include<map>
#include<stack>
#include<set>
#include<ctime>
#define iss ios::sync_with_stdio(false)
using namespace std;
typedef unsigned long long ull;
typedef long long ll;
typedef pair<int,int> pii;
const int mod=1e9+7;
const int MAXN=6e2+5;
const int inf=0x3f3f3f3f;
ll dis[MAXN][MAXN];
int e[MAXN][MAXN];
vector<pii> g[MAXN];
ll ma[MAXN];
int main()
{
    int n,m;
    scanf("%d%d", &n, &m);
    memset(dis, inf, sizeof dis);
    for (int i = 1; i <= m;i++)
    {
        int u, v,w;
        scanf("%d%d%d", &u, &v, &w);
        e[u][v] = e[v][u] = w;
        dis[u][v] = dis[v][u] = w;
    }
    for (int i = 1; i <= n;i++)
        dis[i][i] = 0;
    int q;
    scanf("%d", & q);
    for (int i = 1; i <= q;i++)
    {
        int u, v, l;
        scanf("%d%d%d", &u, &v, &l);
        g[u].push_back({ v, l });
        g[v].push_back({ u, l });
    }
    for (int k = 1; k <= n;k++)
    {
        for (int i = 1; i <= n;i++)
        {
            for (int j = 1; j <= n;j++)
            {
                dis[i][j] = min(dis[i][k] + dis[k][j], dis[i][j]);
            }   
        }
    }
    int ans = 0;
    for (int i = 1; i <= n;i++)
    {
        memset(ma, -inf, sizeof ma);
        for (int v = 1; v <= n;v++)
        {
            for(auto it:g[v])
            {
                ma[v] = max(ma[v], it.second - dis[it.first][i]);
            }
        }
        for (int j = i+1; j <= n;j++)
        {
            if(!e[i][j])
                continue;
            for (int v = 1; v <= n;v++)
            {
                if(e[i][j]+dis[j][v]<=ma[v]){
                    ans++;
                    break;
                }
            }
        }
    }
    printf("%d\n", ans);
}