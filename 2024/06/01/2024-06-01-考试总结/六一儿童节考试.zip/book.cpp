#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 5e6+10;
const int INF = 0x3f3f3f3f;
const int mod = 10081;

int d,n,a[N],tree[N],ans,cnt;

void build(int pos,int l,int r){
	if(l == r){
		tree[pos] = a[l];
		return;
	}
	int mid = (l + r) >> 1;
	build(pos<<1,l,mid);
	build(pos<<1|1,mid+1,r);
	tree[pos] = min(tree[pos<<1],tree[pos<<1|1]);
}

void update(int pos,int l,int r,int val){
	if(l == r) {
		tree[pos] = val,cnt++;
		return;
	}
	int mid = (l + r) >> 1;
	if(tree[pos<<1] <= cnt) update(pos<<1,l,mid,val);
	if(tree[pos<<1|1]<=cnt) update(pos<<1|1,mid+1,r,val);
	tree[pos] = min(tree[pos<<1],tree[pos<<1|1]);
}

signed main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	
	memset(tree,INF,sizeof(tree));
	scanf("%lld%lld",&d,&n);
	for(int i = 1; i <= n; i++)
		scanf("%lld",&a[i]);
	build(1,1,n);
	int ans = 0;
	while(1){
		ans++;
		update(1,1,n,INF);
		if(tree[1] == INF) break;
		if(ans >= n+10){
			puts("-1");
			return 0;
		}
	}
	printf("%lld",ans);
	return 0;
}
