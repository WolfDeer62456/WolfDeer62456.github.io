#include<bits/stdc++.h>
#define int long long
using namespace std;
#define N 1000010

int n,maxn,minn,mxn[N],mnn[N];
bool f[N];
struct node{int x,y,id;}p[N];
bool cmpx(node a,node b){return a.x<b.x;}
bool cmpy(node a,node b){return a.y<b.y;}
void update(int x){
	maxn=max(maxn,x);
	minn=min(minn,x);
	return;
}
bool check(int x,int i){//�ж��Ƿ�ᱻ��ס 
	if(mxn[i]>x&&minn<=x)return true;
	if(mnn[i]<x&&maxn>=x)return true;
	if(maxn>=x&&minn<=x)return true;
	return false;
}
signed main(){
	freopen("sqrex.in","r",stdin);
	freopen("sqrex.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>p[i].x>>p[i].y;
		p[i].id=i;
	}
	sort(p+1,p+n+1,cmpy);
	maxn=-1e18,minn=1e18;
	for(int i=1;i<=n;i++){//Ԥ����y��ȵ���� 
		mxn[i]=mnn[i]=p[i].x;
		if(i>1&&p[i].y==p[i-1].y){
			mxn[i]=max(mxn[i],mxn[i-1]);
			mnn[i]=min(mnn[i],mnn[i-1]);
		}
	}
	for(int i=n-1;i>0;i--){
		if(p[i].y==p[i+1].y){
			mxn[i]=mxn[i+1];
			mnn[i]=mnn[i+1];
		}
	}
	for(int i=1;i<=n;i++){//���� 
		int l=i-1;
		while(l>0&&p[l].y==p[i-1].y&&p[l].y!=p[i].y){
			update(p[l].x);
			l--;
		}
		if(!check(p[i].x,i)){
			f[p[i].id]=true;
		}
	}
	maxn=-1e18,minn=1e18;
	for(int i=n;i>0;i--){//���� 
		int l=i+1;
		while(l<=n&&p[l].y==p[i+1].y&&p[l].y!=p[i].y){
			update(p[l].x);
			l++;
		}
		if(!check(p[i].x,i)){
			f[p[i].id]=true;
		}
	}
	sort(p+1,p+n+1,cmpx);
	for(int i=1;i<=n;i++){//Ԥ����x��ȵ���� 
		mxn[i]=mnn[i]=p[i].y;
		if(i>1&&p[i].x==p[i-1].x){
			mxn[i]=max(mxn[i],mxn[i-1]);
			mnn[i]=min(mnn[i],mnn[i-1]);
		}
	}
	for(int i=n-1;i>0;i--){
		if(p[i].x==p[i+1].x){
			mxn[i]=mxn[i+1];
			mnn[i]=mnn[i+1];
		}
	}
	maxn=-1e18,minn=1e18;
	for(int i=1;i<=n;i++){//��� 
		int l=i-1;
		while(l>0&&p[l].x==p[i-1].x&&p[l].x!=p[i].x){
			update(p[l].y);
			l--;
		}
		if(!check(p[i].y,i)){
			f[p[i].id]=true;
		}
	}
	maxn=-1e18,minn=1e18;
	for(int i=n;i>0;i--){//�Ҳ� 
		int l=i+1;
		while(l<=n&&p[l].x==p[i+1].x&&p[l].x!=p[i].x){
			update(p[l].y);
			l++;
		}
		if(!check(p[i].y,i)){
			f[p[i].id]=true;
		}
	}
	for(int i=1;i<=n;i++){
		if(f[i])cout<<'1';
		else cout<<'0';
	}
	return 0;
}
