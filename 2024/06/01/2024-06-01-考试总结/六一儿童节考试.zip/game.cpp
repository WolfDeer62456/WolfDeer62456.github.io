#include<bits/stdc++.h>
#define Max 1000001
using namespace std;

int n,m,root,head[Max];
int fa[25][Max],dep[Max];
int cnt,vis[Max];
struct graph{
	int to,nxt;
}edge[Max<<1];

void adde(int u,int v){
	edge[++cnt].to=v;
	edge[cnt].nxt=head[u];
	head[u]=cnt;
}

void dfs(int now,int pre){
	vis[now]=1;
	for(int i=head[now];i;i=edge[i].nxt){
		if(!vis[edge[i].to]){
			dep[edge[i].to]=dep[now]+1;
			fa[0][edge[i].to]=now;
			dfs(edge[i].to,now);
		}
	}
}

void init(){
	for(int i=1;i<=log2(n);i++)
		for(int j=1;j<=n;j++)
			fa[i][j]=fa[i-1][fa[i-1][j]];
	return;
}

int lca(int x,int y){
	
	int ans=0;
	
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=log2(n);i>=0;i--)
		if(dep[fa[i][x]]>=dep[y])
			x=fa[i][x],ans+=1<<i;
	
	if(x==y) return ans;
	
	for(int i=log2(n);i>=0;i--){
		if(fa[i][x]!=fa[i][y]){
			x=fa[i][x],y=fa[i][y];
			ans+=(1<<(i+1));
		}
	}
	return ans+2;
}

void read(int&x){
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9')
		x=x*10+ch-48,ch=getchar();
}

int main(){	
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	int d,t;
	read(d),read(t);
	
	while(t--){
		int u,v,a,b,da,db,q;
		cnt=0;
		for(int i=0;i<=n;i++){
			head[i]=0,edge[i]={0,0};
			edge[i+n]={0,0},vis[i]=0;
		}
		
		read(n),read(q);
		for(int i=1;i<n;i++){
			read(u),read(v);
			adde(u,v),adde(v,u);
		}
		
		dep[1]=1;
		dfs(1,0);
		init();
		
		for(int i=1;i<=q;i++){
			read(a),read(b),read(da),read(db);
			if(lca(a,b)<=da) puts("Zayin");
			else if(da<db) puts("Ziyin");
			else if(da>db) puts("Zayin");
			else puts("Draw");
		}
	}
	return 0;
}
